<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="big5">

  <base href="<?= site_url() ?>">

  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= $settings["site_name"] ?></title>

 <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="/public/admin/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="/public/admin/style.css">
    <link rel="stylesheet" type="text/css" href="/public/admin/toastDemo.css">
	<link rel="stylesheet" type="text/css" href="/public/admin/tooltip.css">
	
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/f9fbee3ddf.js" crossorigin="anonymous"></script>

<link rel="stylesheet" href="https://unpkg.com/simplebar@latest/dist/simplebar.css" />
<script src="https://unpkg.com/simplebar@latest/dist/simplebar.min.js"></script>
    <link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/codemirror/3.20.0/codemirror.css">
    <link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/codemirror/3.20.0/theme/monokai.css">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.7.5/css/bootstrap-select.min.css">
    <link rel="stylesheet" type="text/css" href="public/admin/tinytoggle.min.css" rel="stylesheet">
  <script src="https://kit.fontawesome.com/f9fbee3ddf.js" crossorigin="anonymous"></script>
	
  <link href="//gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">

<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" type="text/css" rel="stylesheet">
	<link href="/public/admin/main.css" type="text/css" rel="stylesheet">
	
	
	
	
<style>




  

    nav li {
      font-weight: 500;
    }
    





    html,
    body {
      font-family: 'Inter', sans-serif;
      padding-top: 0px !important;

    }
 

    .noti-icon {
      font-size: 1.5rem;
    }
   




    #loading {
      position: fixed;
      display: flex;
      justify-content: center;
      align-items: center;
      width: 100%;
      height: 100%;
      top: 0;
      left: 0;
      opacity: 0.7;
      background-color: #fff;
      z-index: 99;
    }

    #loading-image {
      z-index: 100;
    }

    #buy-smm {
      margin: 8px 15px;
      font-size: 15px;
      font-weight: 400;
    }

    #buy-smm a {
      cursor: pointer;
    }
  </style>

</head>

<body>

  <div class="container">
    <div class="row">
      <div id="loading">
        <img id="loading-image" src="/public/ajax-loading.gif" alt="Loading..." />
      </div>
    </div>
  </div>


<body class="<?php if($admin["mode"] == "dark"): echo "dark-mode"; endif; ?>">


     <nav class="navbar  navbar-fixed-top   navbar-default">
    <div class="container-fluid">
<div class="navbar-header">
       <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>

      </div>
      <div id="navbar" class="collapse navbar-collapse">
        <ul class="nav navbar-nav navbar-left-block">          <?php if ($admin["access"]["admin_access"]  && $_SESSION["msmbilisim_adminlogin"]) : ?>
        
            
            
            <li class="<?php if (route(1) == "clients") : echo 'active';
                        endif; ?>"><a class="ajax-link" href="<?php echo site_url("admin/clients") ?>"><span> Users</span></a>
            </li>



                        
<li class="" class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> Services<span class="caret"></span></a>
              <ul class="dropdown-menu dropdown-max-height">

<li class="<?php if (route(1) == "services") : echo 'active';
                        endif; ?>"><a class="ajax-link" href="<?php echo site_url("admin/services") ?>"><span> Services</span></a></li>
<li class="<?php if (route(1) == "update-prices") : echo 'active';
                        endif; ?>"><a class="ajax-link" href="<?php echo site_url("admin/update-prices") ?>"><span> Update Prices</span></a></li>
				  
<li class="<?php if (route(1) == "synced_logs") : echo 'active';
                        endif; ?>"><a class="ajax-link" href="<?php echo site_url("admin/synced_logs") ?>"><span> Synced Logs</span></a></li>
				  

       </ul>

            
<li class="" class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Orders<span class="caret"></span></a>
              <ul class="dropdown-menu dropdown-max-height">

<li class="<?php if (route(1) == "orders") : echo 'active';
                        endif; ?>"><a class="ajax-link" href="<?php echo site_url("admin/orders") ?>"><span> Orders</span></a></li>
               
<?php if(countRow(["table"=>"refill_status"])>0){ 
?>
                <li class="<?php if (route(1) == "refill") : echo 'active';
                        endif; ?>"><a class="ajax-link" href="<?php echo site_url("admin/refill") ?>"><span> Refill Logs</span></a></li>
<?php		
			}else{			
			}	
			?>
<?php if(countRow(["table"=>"orders","where"=>["dripfeed"=>2]])>0){   ?>
		
<li class="<?php if (route(1) == "dripfeed") : echo 'active';
                        endif; ?>"><a class="ajax-link" href="<?php echo site_url("admin/dripfeed") ?>"><span>Drip-feeds</span></a></li>
<?php
				
			}else{
				
			}
			
			?>
                </li><?php if(countRow(["table"=>"orders","where"=>["subscriptions_type"=>2]])>0){
			
			?>
<li class="<?php if (route(1) == "subscriptions") : echo 'active';
                        endif; ?>"><a class="ajax-link" href="<?php echo site_url("admin/subscriptions") ?>"><span> Subscriptions</span></a></li>
<?php
				
			}else{
				
			}
			
			?>
              </ul>
            </li>




            <li class="<?php if (route(1) == "payments") : echo 'active';
                        endif; ?>"><a class="ajax-link" href="<?php echo site_url("admin/payments/online") ?>"><span> Payments</span></a>
            </li>

           
            
          

            <li class="<?php if (route(1) == "tickets") : echo 'active';
                        endif; ?>"><a class="ajax-link" href="<?php echo site_url("admin/tickets") ?>"><span> Tickets <?php if(countRow(["table"=>"tickets","where"=>["client_new"=>2]])>0){
			
			?><span class="badge" style="background-color:#cc9616 "><?=countRow(["table"=>"tickets","where"=>["client_new"=>2]]);?></span><?php
				
			}else{
				
			}
			
			?></span></a>
            </li>

           

                

            </li>
     

            <li class="" class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> Additionals <span class="caret"></span></a>
              <ul class="dropdown-menu dropdown-max-height">
				  
            <li class="<?php if (route(1) == "referrals") : echo 'active'; endif; ?>"><li class="<?php if (route(1) == "payouts") : echo 'active';
                        endif; ?>"><a class="ajax-link" href="<?php echo site_url("admin/referrals") ?>"><span> Affiliates</span></a></li>
				   <li class="<?php if (route(1) == "broadcasts") : echo 'active';
                        endif; ?>"><a class="ajax-link" href="<?php echo site_url("admin/broadcasts") ?>"><span> Broadcasts</span></a>
                </li>
				    <li><a class="ajax-link" href="<?php echo site_url("admin/logs") ?>"><span> Logs</span></a>
                </li>

                <li><a class="ajax-link" href="<?php echo site_url("admin/reports") ?>"><span> Reports</span></a>
                </li>
              <li class="<?php if (route(1) == "earn") : echo 'active';
                        endif; ?>"><a class="ajax-link" href="<?php echo site_url("admin/earn") ?>"><span> Promotion</span></a></li>
                        
                <li class="<?php if (route(1) == "kuponlar") : echo 'active';
                        endif; ?>"><a class="ajax-link" href="<?php echo site_url("admin/kuponlar") ?>"><span> Coupon Code</span></a></li>


                <li class="<?php if (route(1) == "child-panels") : echo 'active';
                        endif; ?>"><a class="ajax-link" href="<?php echo site_url("admin/child-panels") ?>"><span> Child Panels</span></a></li>
<li class="<?php if (route(1) == "updates") : echo 'active';
                        endif; ?>"><a class="ajax-link" href="<?php echo site_url("admin/updates") ?>"><span> Updates</span></a></li>

               

              </ul>
            </li>

</li>
<li class="<?php if (route(1) == "appearance") : echo 'active';
                        endif; ?>"><a class="ajax-link" href="<?php echo site_url("admin/appearance") ?>"><span> Appearance</span></a>
            </li>

            <li class="<?php if (route(1) == "settings") : echo 'active';
                        endif; ?>"><a class="ajax-link" href="<?php echo site_url("admin/settings") ?>"><span> Settings</span></a>
            </li>
</ul>  
<ul id='w4' class='nav navbar-nav navbar-right'>
         <?php if ($admin["mode"] == "dark") : ?>

<li><a href="admin?mode=sun">Day Mode<span></span></a></li>

<?php else: ?>

<li><a href="admin?mode=dark">Night Mode<span></span></a></li>


<?php endif; ?>
<li class="<?php if (route(1) == "account") : echo 'active';
                        endif; ?>"><a class="ajax-link" href="<?php echo site_url("admin/account") ?>"><span> Account</span></a>
            </li>
          <?php endif; ?>
        


        <li><a href="admin/logout"><span> Logout</span></a>
        </ul></li></ul> 
      </div>

    </div>
  </nav>
<br><br><br><br>