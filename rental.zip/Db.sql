-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 26, 2023 at 05:53 AM
-- Server version: 5.7.40
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smmscrip_free`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(225) DEFAULT NULL,
  `password` text NOT NULL,
  `register_date` datetime NOT NULL,
  `login_date` datetime DEFAULT NULL,
  `login_ip` varchar(225) DEFAULT NULL,
  `client_type` enum('1','2') NOT NULL DEFAULT '2' COMMENT '2 -> ON, 1 -> OFF',
  `access` varchar(999) NOT NULL,
  `mode` varchar(225) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `username`, `password`, `register_date`, `login_date`, `login_ip`, `client_type`, `access`, `mode`) VALUES
(1, 'admin', 'admin', '2021-09-08 10:19:05', '2023-01-26 08:30:58', '132.154.131.242', '2', '{\"admin_access\":\"1\",\"users\":\"1\",\"orders\":\"1\",\"subscriptions\":\"1\",\"dripfeed\":\"1\",\"services\":\"1\",\"payments\":\"1\",\"tickets\":\"1\",\"reports\":\"1\",\"general_settings\":\"1\",\"pages\":\"1\",\"payments_settings\":\"1\",\"bank_accounts\":\"1\",\"payments_bonus\":\"1\",\"alert_settings\":\"1\",\"providers\":\"1\",\"themes\":\"1\",\"child-panels\":\"1\",\"language\":\"1\",\"meta\":\"1\",\"twice\":\"1\",\"files\":\"1\",\"coupon\":\"1\",\"admins\":\"1\",\"update-prices\":\"1\",\"bulk\":\"1\",\"bulkc\":\"1\",\"synced-logs\":\"1\",\"refill\":\"1\",\"referral\":\"1\",\"broadcast\":\"1\",\"logs\":\"1\",\"videop\":\"1\",\"updates\":\"1\",\"menu\":\"1\",\"inte\":\"1\",\"currency\":\"1\",\"news\":\"1\",\"blog\":\"1\",\"modules\":\"1\",\"subject\":\"1\"}', 'dark');

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

CREATE TABLE `article` (
  `id` int(11) NOT NULL,
  `title` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `published_at` datetime DEFAULT NULL,
  `image_file` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bank_accounts`
--

CREATE TABLE `bank_accounts` (
  `id` int(11) NOT NULL,
  `bank_name` varchar(225) NOT NULL,
  `bank_sube` varchar(225) NOT NULL,
  `bank_hesap` varchar(225) NOT NULL,
  `bank_iban` text NOT NULL,
  `bank_alici` varchar(225) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

CREATE TABLE `blogs` (
  `id` int(11) NOT NULL,
  `title` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `published_at` datetime NOT NULL,
  `image_file` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('1','2') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `blog_get` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bulkedit`
--

CREATE TABLE `bulkedit` (
  `id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `category_name` text COLLATE utf8mb4_bin NOT NULL,
  `category_line` double NOT NULL,
  `category_type` enum('1','2') CHARACTER SET utf8 NOT NULL DEFAULT '2',
  `category_secret` enum('1','2') COLLATE utf8mb4_bin NOT NULL DEFAULT '2',
  `category_icon` text COLLATE utf8mb4_bin NOT NULL,
  `is_refill` enum('1','2') CHARACTER SET utf8 NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`, `category_line`, `category_type`, `category_secret`, `category_icon`, `is_refill`) VALUES
(1, ' 𝙊𝙪𝙧 special sale [ Cheapest Rate Gurantee ] 💎', 1, '2', '2', '', ''),
(2, '🔵 Blue Tick  Verification for Instagram [ All countries ✅ ] { 100% Refund Gurantee } ', 2, '2', '2', '', ''),
(3, ' 𝙈𝙊𝙉𝙀𝙏𝙄𝙕𝙀  YOUR Y0UTUBE  CHANNEL IN  [ 7 DAYS ]  📽🖥🖲', 3, '2', '2', '', ''),
(4, 'YouTube Adwords views [ Indian , worldwide, targeted ]  Available ', 4, '2', '2', '', ''),
(5, 'Increase  Revenue [ Dollar ] 💵 In Your YouTube Channel 💰💸', 5, '2', '2', '', ''),
(6, 'Create your own smm panel like us [ 𝙊𝙬𝙣 𝙒𝙀𝘽𝙎𝙄𝙏𝙀 ] 🌐', 6, '2', '2', '', ''),
(7, ' Report  Spam Account [ Instagram ID BAN ] ❌', 7, '2', '2', '', ''),
(8, 'Premium Accounts  [ Amazon Prime, Netflix.. ] ', 8, '2', '2', '', ''),
(9, 'Increase Your Instagram Growth [ Organic ]', 9, '2', '2', '', ''),
(10, 'Instagram 𝗥𝗲𝗲𝗹𝘀  𝗩𝗶𝗲𝘄𝘀  [ Non- Drop ] [ Instant Starting ] ', 10, '2', '2', '', ''),
(11, 'Instagram Verified Account Followers, Comment💬 [ 💎 ]', 11, '2', '2', '', ''),
(12, 'Instagram 𝙋𝙧𝙚𝙢𝙞𝙪𝙢  Followers [ VIP ]  HQ💎 [ 𝘼𝙘𝙩𝙞𝙫𝙚 Profiles ] [ High quality 💎💎💎]', 12, '2', '2', '', ''),
(13, 'Instagram 100% 𝙄𝙣𝙙𝙞𝙖𝙣  🇮🇳 Followers   𝘼𝙘𝙩𝙞𝙫𝙚 𝙋𝙧𝙤𝙛𝙞𝙡𝙚𝙨 [ Non-Drop ]', 13, '2', '2', '', ''),
(14, 'Instagram Followers  [ 𝟑𝟔𝟓 𝐃𝐚𝐲𝐬 ] days Gurantee [ Non- Drop ]', 14, '2', '2', '', ''),
(15, 'Instagram Followers [ Bots ]  [ Bullet speed ] 🤖🤖🤖', 15, '2', '2', '', ''),
(16, 'Instagram 𝗟𝗶𝗸𝗲𝘀  Indian 🇮🇳  [Ads- 𝗠𝗲𝘁𝗵𝗼𝗱  ] Non- Drop ', 16, '2', '2', '', ''),
(17, '𝗜𝗻𝘀𝘁𝗮𝗴𝗿𝗮𝗺  Likes [  𝐍𝐨𝐧-𝐃𝐫𝐨𝐩 ]   𝗩𝗜𝗣  Quality 💎', 17, '2', '2', '', ''),
(18, 'Instagram Comments 💬 🇮🇳  [ Non- Drop ] ', 18, '2', '2', '', ''),
(19, 'Instagram Impression / Highlights / Reach / Profile Visit / saves ', 19, '2', '2', '', ''),
(20, 'Instagram Story views [ Enter Your Exact Username  ] ', 20, '2', '2', '', ''),
(21, 'YouTube Views [ Non- Drop Premium Quality', 21, '2', '2', '', ''),
(22, 'Youtube Subscriber [ Bots ] [ Instant ] [ Prank subscribe]', 22, '2', '2', '', ''),
(23, 'YouTube Subscribe [ Non- Drop ]  [ Organic ] [ Lifetime Guarantee ] 💎♻️♻️', 23, '2', '2', '', ''),
(24, 'YouTube Watchtime   [ High Quality ]  [ Non-Drop ] 💎', 24, '2', '2', '', ''),
(25, 'YouTube Likes [ 𝐍𝐨𝐧 - 𝐃𝐫𝐨𝐩 ]  ', 25, '2', '2', '', ''),
(26, 'YouTube  - Comments 💬   / Comment Likes [ 𝐇𝐢𝐠𝐡 𝐪𝐮𝐚𝐥𝐢𝐭𝐲 ] 💎', 26, '2', '2', '', ''),
(27, 'YouTube Live Stream 💎', 27, '2', '2', '', ''),
(28, 'Twitter', 28, '2', '2', '', ''),
(29, 'TikTok MIX Services PRIMARY PROVIDER', 29, '2', '2', '', ''),
(30, 'Facebook Comments', 30, '2', '2', '', ''),
(31, 'Facebook - Post  Likes ', 31, '2', '2', '', ''),
(32, 'Facebook - Page Likes  Followers ', 32, '2', '2', '', ''),
(33, 'Facebook - MONETIZE Views', 33, '2', '2', '', ''),
(34, 'Facebook - Live Stream Views [INSTANT]', 34, '2', '2', '', ''),
(35, 'Facebook - Live Stream  Likes', 35, '2', '2', '', ''),
(36, 'Discord Services ', 36, '2', '2', '', ''),
(37, 'Discord (DM) Direct Message | MAIN PROVIDER', 37, '2', '2', '', ''),
(38, 'Telegram - Reactions', 38, '2', '2', '', ''),
(39, 'Telegram - Views ', 39, '2', '2', '', ''),
(40, 'Telegram Members - [All SIM Cards]', 40, '2', '2', '', ''),
(41, 'Telegram Members - [Refill or No Drop]', 41, '2', '2', '', ''),
(42, 'Telegram Members [🇺🇸🇮🇷]', 42, '2', '2', '', ''),
(43, 'Telegram Target Members - [REAL]', 43, '2', '2', '', ''),
(44, 'Telegram Target Members - [BOT]', 44, '2', '2', '', ''),
(45, 'Telegram Comments - Vote - Other', 45, '2', '2', '', ''),
(46, 'ClubHouse Package Followers', 46, '2', '2', '', ''),
(47, 'Instagram Other', 47, '2', '2', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `childpanels`
--

CREATE TABLE `childpanels` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `domain` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `currency` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `child_username` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `child_password` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `charge` double NOT NULL,
  `status` enum('Pending','Active','Frozen','Suspended') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Pending',
  `renewal_date` date NOT NULL,
  `date_created` datetime NOT NULL,
  `dreampanel_id` int(11) NOT NULL,
  `keyc` varchar(225) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `client_id` int(11) NOT NULL,
  `name` varchar(225) DEFAULT NULL,
  `email` varchar(225) NOT NULL,
  `username` varchar(225) DEFAULT NULL,
  `admin_type` enum('1','2') NOT NULL DEFAULT '2',
  `password` text NOT NULL,
  `telephone` varchar(225) DEFAULT NULL,
  `balance` decimal(21,4) NOT NULL,
  `balance_type` enum('1','2') NOT NULL DEFAULT '2',
  `debit_limit` double DEFAULT NULL,
  `spent` decimal(21,4) NOT NULL,
  `register_date` datetime NOT NULL,
  `login_date` datetime DEFAULT NULL,
  `login_ip` varchar(225) DEFAULT NULL,
  `apikey` text NOT NULL,
  `tel_type` enum('1','2') NOT NULL DEFAULT '1' COMMENT '2 -> ON, 1 -> OFF',
  `email_type` enum('1','2') NOT NULL DEFAULT '1' COMMENT '2 -> ON, 1 -> OFF',
  `client_type` enum('1','2') NOT NULL DEFAULT '2' COMMENT '2 -> ON, 1 -> OFF',
  `access` text,
  `lang` varchar(255) NOT NULL DEFAULT 'tr',
  `timezone` double NOT NULL DEFAULT '0',
  `currency_type` enum('INR','USD') NOT NULL DEFAULT 'USD',
  `ref_code` text NOT NULL,
  `ref_by` text,
  `change_email` enum('1','2') NOT NULL DEFAULT '2',
  `resend_max` int(11) NOT NULL,
  `currency` varchar(225) NOT NULL DEFAULT '1',
  `passwordreset_token` varchar(225) NOT NULL,
  `coustm_rate` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`client_id`, `name`, `email`, `username`, `admin_type`, `password`, `telephone`, `balance`, `balance_type`, `debit_limit`, `spent`, `register_date`, `login_date`, `login_ip`, `apikey`, `tel_type`, `email_type`, `client_type`, `access`, `lang`, `timezone`, `currency_type`, `ref_code`, `ref_by`, `change_email`, `resend_max`, `currency`, `passwordreset_token`, `coustm_rate`) VALUES
(1, '', 'helloworld2@lmao.com', 'helloworld', '2', '432a4d005958f5192b640e1602277c63', '', '0.0000', '2', NULL, '0.0000', '2022-08-12 14:41:14', NULL, NULL, '05bc32321b7b80008be40ee8acc3ba10', '1', '2', '2', NULL, 'en', 0, 'USD', '463a1d', NULL, '2', 0, '1', '', 50),
(2, '', 'sidharthkumar2028@gmail.com', 'sidharthkumar', '2', '6fa6ca81e5a1e230d70fd0fd2d065ec6', '', '0.0000', '2', NULL, '0.0000', '2022-12-13 10:55:35', NULL, NULL, 'b9cddb649ffa653503dd8c867f9f93fe', '1', '2', '2', NULL, 'en', 0, 'USD', 'bce776', NULL, '2', 0, '2', '2115b03864f98ff8057cdf7a6e6f0d71', 0),
(3, '', 'nilkanthpatelrsllp65@gmail.com', 'Unlock', '2', '25d55ad283aa400af464c76d713c07ad', '', '0.0000', '2', NULL, '0.0000', '2022-12-13 10:57:32', '2023-01-26 08:27:55', '132.154.131.242', '6e911c2fee3fa5885eafa15ce3d000bb', '1', '2', '2', NULL, 'en', 0, 'USD', '46b934', NULL, '2', 0, '1', '', 0),
(4, '', 'lopob84568@hoxds.com', 'ersesj', '2', '64e1b8d34f425d19e1ee2ea7236d3028', '', '0.0000', '2', NULL, '0.0000', '2022-12-13 12:23:07', NULL, NULL, 'd50978be708af584423ff806e8e0deff', '1', '2', '2', NULL, 'en', 0, 'USD', 'd3d362', NULL, '2', 0, '1', '', 0),
(5, '', '123456787@gmail.com', 'Harsh123', '2', '657452be1879168ccac09510e9320cb5', '', '0.0000', '2', NULL, '0.0000', '2022-12-13 22:22:25', NULL, NULL, 'cfc4b01c3a386ded5feb1a743b9e9cce', '1', '2', '2', NULL, 'en', 0, 'USD', '1e1f7e', NULL, '2', 0, '2', '', 0),
(6, '', 'sajibnamo1@gmail.com', 'SajibNamo', '2', 'af310b7d2a5619e66d599011652b2421', '', '0.0000', '2', NULL, '0.0000', '2022-12-15 11:49:23', '2022-12-15 15:07:33', '103.133.203.245', 'c2785959a442a0de2aa075a1166f5249', '1', '2', '2', NULL, 'en', 0, 'USD', '961764', NULL, '2', 0, '1', '1f10c045c7c173c55098769dd86690b9', 0),
(7, '', 'aliiamin8899@gmail.com', 'shadowyt077', '2', '71e2d5db01b9b19f7658976b071ef96d', '', '0.0000', '2', NULL, '0.0000', '2022-12-27 19:21:54', NULL, NULL, '7c37fdea7f2ab2fbfdd8c7223afa6cf1', '1', '2', '2', NULL, 'en', 0, 'USD', 'bbc86e', NULL, '2', 0, '2', '', 0),
(8, '', 'aryandulta@gmail.com', 'aryandulta', '2', '7b44c7591819fdc5a663acf92b98051a', '', '0.0000', '2', NULL, '0.0000', '2023-01-02 19:28:29', NULL, NULL, 'a9e9e77b3d81094aa3992ddf98fd740d', '1', '2', '2', NULL, 'en', 0, 'USD', '447329', NULL, '2', 0, '1', '', 0),
(9, '', 'palm17431@gmail.com', 'Mayank', '2', '0549059d82538a71e453bae376982265', '', '0.0000', '2', NULL, '0.0000', '2023-01-07 21:10:11', NULL, NULL, '6beee5347d096cff5217f5f3bd36e165', '1', '2', '2', NULL, 'en', 0, 'USD', '80ca40', NULL, '2', 0, '1', '', 0),
(10, '', 'smmscriptshop@gmail.com', 'unlock12', '2', '25d55ad283aa400af464c76d713c07ad', '', '0.0000', '2', NULL, '0.0000', '2023-01-25 14:15:13', '2023-01-25 15:54:46', '185.220.101.9', 'c26220e79fcfb574d2928597bd142bab', '1', '2', '2', NULL, 'en', 0, 'USD', '2650f3', NULL, '2', 0, '2', '', 0),
(11, '', 'thumbnail@gmail.com', 'thumbnail', '2', '25d55ad283aa400af464c76d713c07ad', '', '0.0000', '2', NULL, '0.0000', '2023-01-25 14:33:33', '2023-01-25 14:39:19', '202.14.123.210', 'cfe96d239ab9141923787f630a27a6f8', '1', '2', '2', NULL, 'en', 0, 'USD', 'dae15f', NULL, '2', 0, '1', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `clients_category`
--

CREATE TABLE `clients_category` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `clients_price`
--

CREATE TABLE `clients_price` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `service_price` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `clients_service`
--

CREATE TABLE `clients_service` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `client_report`
--

CREATE TABLE `client_report` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `action` text NOT NULL,
  `report_ip` varchar(225) NOT NULL,
  `report_date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `client_report`
--

INSERT INTO `client_report` (`id`, `client_id`, `action`, `report_ip`, `report_date`) VALUES
(1, 1, '\r\n    User registered.', '2401:4900:1c36:2482:69d6:4c91:3db4:23c5, 162.158.235.69', '2022-08-12 14:41:14'),
(2, 2, '\r\n    User registered.', '223.235.241.37', '2022-12-13 10:55:35'),
(3, 2, 'API Key changed', '223.235.241.37', '2022-12-13 10:56:19'),
(4, 3, '\r\n    User registered.', '47.31.98.47', '2022-12-13 10:57:32'),
(5, 4, '\r\n    User registered.', '105.112.121.76', '2022-12-13 12:23:07'),
(6, 3, 'Member logged in.', '47.31.98.47', '2022-12-13 12:24:53'),
(7, 5, '\r\n    User registered.', '49.42.65.47', '2022-12-13 22:22:25'),
(8, 6, '\r\n    User registered.', '103.133.203.245', '2022-12-15 11:49:23'),
(9, 6, 'Member logged in.', '103.133.203.245', '2022-12-15 15:04:23'),
(10, 6, 'Member logged in.', '103.133.203.245', '2022-12-15 15:06:09'),
(11, 6, 'Member logged in.', '103.133.203.245', '2022-12-15 15:07:33'),
(12, 3, 'Member logged in.', '47.31.96.64', '2022-12-16 16:12:59'),
(13, 3, 'Member logged in.', '157.39.21.203', '2022-12-22 17:35:19'),
(14, 7, '\r\n    User registered.', '103.159.35.151', '2022-12-27 19:21:54'),
(15, 3, 'Member logged in.', '157.39.2.27', '2022-12-31 15:44:56'),
(16, 8, '\r\n    User registered.', '106.192.133.87', '2023-01-02 19:28:29'),
(17, 9, '\r\n    User registered.', '106.196.71.171', '2023-01-07 21:10:11'),
(18, 3, 'Member logged in.', '157.39.64.220', '2023-01-25 13:47:56'),
(19, 10, '\r\n    User registered.', '157.39.64.220', '2023-01-25 14:15:13'),
(20, 11, '\r\n    User registered.', '202.14.123.210', '2023-01-25 14:33:33'),
(21, 11, 'Member logged in.', '202.14.123.210', '2023-01-25 14:39:19'),
(22, 10, 'Member logged in.', '185.220.101.9', '2023-01-25 15:54:46'),
(23, 3, 'Member logged in.', '132.154.131.242', '2023-01-26 08:27:55');

-- --------------------------------------------------------

--
-- Table structure for table `currency`
--

CREATE TABLE `currency` (
  `id` int(11) NOT NULL,
  `symbol` text,
  `value` double DEFAULT NULL,
  `name` varchar(225) NOT NULL,
  `status` enum('1','2') NOT NULL DEFAULT '1',
  `default` enum('2','1') NOT NULL DEFAULT '2',
  `nouse` enum('1','2') NOT NULL DEFAULT '2'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `currency`
--

INSERT INTO `currency` (`id`, `symbol`, `value`, `name`, `status`, `default`, `nouse`) VALUES
(1, '$', 1, 'USD', '1', '1', '1'),
(2, '₹', 75, 'INR', '1', '2', '2'),
(5, '€', 0.94, 'Euro', '1', '2', '2');

-- --------------------------------------------------------

--
-- Table structure for table `earn`
--

CREATE TABLE `earn` (
  `earn_id` int(255) NOT NULL,
  `client_id` int(255) NOT NULL,
  `link` text NOT NULL,
  `earn_note` text NOT NULL,
  `status` enum('Pending','Under Review','Funds Granted','Rejected','Not Eligible') NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `id` int(11) NOT NULL,
  `link` text,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `General_options`
--

CREATE TABLE `General_options` (
  `id` int(11) NOT NULL,
  `coupon_status` enum('1','2') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `updates_show` enum('1','2') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `panel_status` enum('Pending','Active','Frozen','Suspended') COLLATE utf8_unicode_ci NOT NULL,
  `panel_orders` int(11) NOT NULL,
  `panel_thismonthorders` int(11) NOT NULL,
  `massorder` enum('1','2') COLLATE utf8_unicode_ci NOT NULL DEFAULT '2',
  `balance_format` enum('0.0','0.00','0.000','0.0000') COLLATE utf8_unicode_ci NOT NULL DEFAULT '0.0',
  `currency_format` enum('0','2','3','4') COLLATE utf8_unicode_ci NOT NULL DEFAULT '3',
  `ticket_system` enum('1','2') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `General_options`
--

INSERT INTO `General_options` (`id`, `coupon_status`, `updates_show`, `panel_status`, `panel_orders`, `panel_thismonthorders`, `massorder`, `balance_format`, `currency_format`, `ticket_system`) VALUES
(1, '', '2', 'Active', 1024, 20, '2', '', '4', '2');

-- --------------------------------------------------------

--
-- Table structure for table `integrations`
--

CREATE TABLE `integrations` (
  `id` int(11) NOT NULL,
  `name` varchar(225) NOT NULL,
  `description` varchar(225) NOT NULL,
  `icon_url` varchar(225) NOT NULL,
  `code` text NOT NULL,
  `visibility` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `integrations`
--

INSERT INTO `integrations` (`id`, `name`, `description`, `icon_url`, `code`, `visibility`, `status`) VALUES
(1, 'Beamer', 'Announce updates and get feedback with in-app notification center, widgets and changelog', '/img/integrations/Beamer.svg', '', 1, 1),
(2, 'Getsitecontrol', 'It helps you prevent website visitors from leaving your website without taking any action.', '/img/integrations/Getsitecontrol.svg', '', 1, 1),
(3, 'Google Analytics', 'Statistics and basic analytical tools for search engine optimization (SEO) and marketing purposes', '/img/integrations/Google%20Analytics.svg', '', 1, 2),
(4, 'Google Tag manager', 'Manage all your website tags without editing the code using simple tag management solutions', '/img/integrations/Google%20Tag%20manager.svg', '', 1, 1),
(5, 'JivoChat', 'All-in-one business messenger to talk to customers: live chat, phone, email and social', '/img/integrations/JivoChat.svg', '', 1, 1),
(6, 'Onesignal', 'Leader in customer engagement, empowers mobile push, web push, email, in-app messages', '/img/integrations/Onesignal.svg', '', 1, 1),
(7, 'Push alert', 'Increase reach, revenue, retarget users with Push Notifications on desktop and mobile', '/img/integrations/Push%20alert.svg', '', 1, 2),
(8, 'Smartsupp', 'Live chat, email inbox and Facebook Messenger in one customer messaging platform', '/img/integrations/Smartsupp.svg', '', 1, 1),
(9, 'Tawk.to', 'Track and chat with visitors on your website, mobile app or a free customizable page', '/img/integrations/Tawk.to.svg', '', 1, 1),
(10, 'Tidio', 'Communicator for businesses that keep live chat, chatbots, Messenger and email in one place', '/img/integrations/Tidio.svg', '', 1, 1),
(11, 'Zendesk Chat', 'Helps respond quickly to customer questions, reduce wait times and increase sales', '/img/integrations/Zendesk%20Chat.svg', '', 1, 1),
(12, 'Getbutton.io', 'Chat with website visitors through popular messaging apps. Whatsapp, messenger etc. contact button.', '/img/integrations/Getbutton.svg', 'Hii', 1, 1),
(13, 'Google reCAPTCHA v2', 'It uses an advanced risk analysis engine and adaptive challenges to prevent malware from engaging in abusive activities on your website.', '/img/integrations/reCAPTCHA.svg', '', 1, 2),
(14, 'Whatsapp', 'Whatsapp is for Personal Support of your Users', '/img/integrations/whatsapp.svg', '', 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `kuponlar`
--

CREATE TABLE `kuponlar` (
  `id` int(11) NOT NULL,
  `kuponadi` varchar(255) NOT NULL,
  `adet` int(11) NOT NULL,
  `tutar` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `kupon_kullananlar`
--

CREATE TABLE `kupon_kullananlar` (
  `id` int(11) NOT NULL,
  `uye_id` int(11) NOT NULL,
  `kuponadi` varchar(255) NOT NULL,
  `tutar` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE `languages` (
  `id` int(11) NOT NULL,
  `language_name` varchar(225) NOT NULL,
  `language_code` varchar(225) NOT NULL,
  `language_type` enum('2','1') NOT NULL DEFAULT '2',
  `default_language` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `language_name`, `language_code`, `language_type`, `default_language`) VALUES
(1, 'English', 'en', '2', '1');

-- --------------------------------------------------------

--
-- Table structure for table `Mailforms`
--

CREATE TABLE `Mailforms` (
  `id` int(11) NOT NULL,
  `subject` varchar(225) NOT NULL,
  `message` varchar(225) NOT NULL,
  `status` enum('1','2') NOT NULL DEFAULT '1',
  `header` varchar(225) NOT NULL,
  `footer` varchar(225) NOT NULL,
  `type` enum('Admins','Users') NOT NULL DEFAULT 'Users'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `id` int(11) NOT NULL,
  `name` text COLLATE utf8mb4_bin NOT NULL,
  `menu_line` double NOT NULL,
  `type` enum('1','2') CHARACTER SET utf8 NOT NULL DEFAULT '2',
  `slug` varchar(225) COLLATE utf8mb4_bin NOT NULL DEFAULT '2',
  `icon` varchar(225) COLLATE utf8mb4_bin DEFAULT NULL,
  `menu_status` enum('1','2') CHARACTER SET utf8 NOT NULL DEFAULT '1',
  `visible` enum('Internal','External') COLLATE utf8mb4_bin NOT NULL DEFAULT 'Internal',
  `active` varchar(225) COLLATE utf8mb4_bin NOT NULL,
  `tiptext` varchar(225) COLLATE utf8mb4_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `name`, `menu_line`, `type`, `slug`, `icon`, `menu_status`, `visible`, `active`, `tiptext`) VALUES
(2, 'Orders ', 2, '2', '/orders', 'fas fa-server', '1', 'Internal', 'massorder', 'Shown only if Mass Order system enabled for use'),
(3, 'New Order', 1, '2', '/', 'fas fa-cart-arrow-down', '1', 'Internal', 'orders', ''),
(4, 'Refill', 3, '2', '/refill', 'fas fa-recycle', '1', 'Internal', 'refill', 'Shown only if user have at least one refill task'),
(5, 'Login', 2, '2', '/', 'fas fa-sign-in-alt', '1', 'External', 'login', ''),
(6, 'Services', 4, '2', '/services', 'fas fa-cogs', '1', 'Internal', 'services', ''),
(7, 'Add Funds', 5, '2', '/addfunds', 'fas fa-credit-card', '1', 'Internal', 'addfunds', ''),
(8, 'Api', 6, '2', '/api', 'fas fa-code', '1', 'Internal', 'api', ''),
(9, 'Tickets ', 7, '2', '/tickets', 'fas fa-headset', '1', 'Internal', 'tickets', ''),
(10, 'Child Panels', 8, '2', '/child-panels', 'fas fa-child', '1', 'Internal', 'child-panels', 'Shown only if child panels selling enabled'),
(11, 'Refer & Earn', 11, '2', '/refer', 'fas fa-bezier-curve', '1', 'Internal', 'refer', 'Shown only if affiliate system enabled for use'),
(14, 'Signup ', 3, '2', '/signup', 'fas fa-user-plus', '1', 'External', 'signup', 'Shown only if Signup system enabled for use'),
(15, 'Api', 4, '2', '/apis', 'fas fa-code', '1', 'External', 'api', ''),
(18, 'Services', 5, '2', '/service/USD', 'fas fa-list-alt', '1', 'External', 'terms', ''),
(27, 'Service Updates', 9, '2', '/updates', 'fas fa-wrench', '1', 'Internal', 'updates', ''),
(30, 'Mass Order', 10, '2', '/massorder', 'fas fa-cart-plus', '1', 'Internal', 'subscriptions', '');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `news_icon` varchar(225) NOT NULL,
  `news_title` varchar(225) NOT NULL,
  `news_content` varchar(225) NOT NULL,
  `news_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `news_icon`, `news_title`, `news_content`, `news_date`) VALUES
(1, 'facebook', 'Hii', 'Hii', '2022-08-12 14:06:14');

-- --------------------------------------------------------

--
-- Table structure for table `notifications_popup`
--

CREATE TABLE `notifications_popup` (
  `id` int(11) NOT NULL,
  `title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `action_link` text NOT NULL,
  `isAllPage` enum('0','1') NOT NULL DEFAULT '0',
  `isAllUser` enum('1','0') NOT NULL DEFAULT '0',
  `expiry_date` date NOT NULL,
  `status` enum('1','2','0') NOT NULL DEFAULT '1',
  `allPages` varchar(225) NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `action_text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `notifications_popup`
--

INSERT INTO `notifications_popup` (`id`, `title`, `action_link`, `isAllPage`, `isAllUser`, `expiry_date`, `status`, `allPages`, `description`, `action_text`) VALUES
(2, 'welcome', '', '1', '0', '2022-12-24', '1', 'null', '<p>Rental Panel</p>', ''),
(3, 'ok', '', '1', '0', '2023-01-27', '1', 'null', '<p>ok</p>', '');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `api_orderid` int(11) NOT NULL DEFAULT '0',
  `order_error` text NOT NULL,
  `order_detail` text,
  `order_api` int(11) NOT NULL DEFAULT '0',
  `api_serviceid` int(11) NOT NULL DEFAULT '0',
  `api_charge` double NOT NULL DEFAULT '0',
  `api_currencycharge` double DEFAULT '1',
  `order_profit` double NOT NULL,
  `order_quantity` double NOT NULL,
  `order_extras` text NOT NULL,
  `order_charge` double NOT NULL,
  `dripfeed` enum('1','2','3') DEFAULT '1' COMMENT '2 -> ON, 1 -> OFF',
  `dripfeed_id` double NOT NULL DEFAULT '0',
  `subscriptions_id` double NOT NULL DEFAULT '0',
  `subscriptions_type` enum('1','2') NOT NULL DEFAULT '1' COMMENT '2 -> ON, 1 -> OFF',
  `dripfeed_totalcharges` double DEFAULT NULL,
  `dripfeed_runs` double DEFAULT NULL,
  `dripfeed_delivery` double NOT NULL DEFAULT '0',
  `dripfeed_interval` double DEFAULT NULL,
  `dripfeed_totalquantity` double DEFAULT NULL,
  `dripfeed_status` enum('active','completed','canceled') NOT NULL DEFAULT 'active',
  `order_url` text NOT NULL,
  `order_start` double NOT NULL DEFAULT '0',
  `order_finish` double NOT NULL DEFAULT '0',
  `order_remains` double NOT NULL DEFAULT '0',
  `order_create` datetime NOT NULL,
  `order_status` enum('pending','inprogress','completed','partial','processing','canceled') NOT NULL DEFAULT 'pending',
  `subscriptions_status` enum('active','paused','completed','canceled','expired','limit') NOT NULL DEFAULT 'active',
  `subscriptions_username` text,
  `subscriptions_posts` double DEFAULT NULL,
  `subscriptions_delivery` double NOT NULL DEFAULT '0',
  `subscriptions_delay` double DEFAULT NULL,
  `subscriptions_min` double DEFAULT NULL,
  `subscriptions_max` double DEFAULT NULL,
  `subscriptions_expiry` date DEFAULT NULL,
  `last_check` datetime NOT NULL,
  `order_where` enum('site','api') NOT NULL DEFAULT 'site',
  `refill_status` enum('Pending','Refilling','Completed','Rejected','Error') NOT NULL DEFAULT 'Pending',
  `is_refill` enum('1','2') NOT NULL DEFAULT '1',
  `refill` varchar(225) NOT NULL DEFAULT '1',
  `cancelbutton` enum('1','2') NOT NULL DEFAULT '1' COMMENT '1 -> ON, 2 -> OFF',
  `show_refill` enum('true','false') NOT NULL DEFAULT 'true',
  `api_refillid` double NOT NULL DEFAULT '0',
  `avg_done` enum('0','1') NOT NULL DEFAULT '1',
  `order_increase` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `page_id` int(11) NOT NULL,
  `page_name` varchar(225) NOT NULL,
  `page_get` varchar(225) NOT NULL,
  `page_content` text NOT NULL,
  `page_status` enum('1','2') NOT NULL DEFAULT '1',
  `active` enum('1','2') NOT NULL DEFAULT '1',
  `seo_title` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `seo_keywords` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `seo_description` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `last_modified` datetime NOT NULL,
  `del` varchar(255) NOT NULL DEFAULT '1',
  `page_content2` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`page_id`, `page_name`, `page_get`, `page_content`, `page_status`, `active`, `seo_title`, `seo_keywords`, `seo_description`, `last_modified`, `del`, `page_content2`) VALUES
(2, 'Add funds', 'addfunds', '', '1', '1', '', '', '', '2022-02-07 08:23:09', '2', ''),
(787, 'Login', 'auth', '', '1', '1', 'SMMSCRIPT.SHOP', '', '', '2023-01-25 03:46:59', '2', '<div style=\"text-align: center;\"><br></div>'),
(9, 'New Order', 'neworder', '<p><br></p>', '1', '1', '', '', '', '2023-01-25 03:48:46', '2', '<p><br></p><p><br></p>'),
(14, 'Terms', 'terms', '', '1', '1', '', '', '', '2022-02-07 08:41:16', '2', ''),
(789, 'Mass Order', 'massorder', '', '1', '1', '', '', '', '2022-02-07 08:43:06', '2', ''),
(790, 'Orders', 'orders', '', '1', '1', '', '', '', '2022-02-07 08:53:20', '2', ''),
(791, 'Services', 'services', '', '1', '1', '', '', '', '2022-01-26 07:22:09', '2', ''),
(792, 'Tickets', 'tickets', '', '1', '1', '', '', '', '2022-01-26 07:22:09', '2', ''),
(793, 'API', 'api', '', '1', '1', '', '', '', '2022-01-24 07:21:07', '2', ''),
(794, 'Signup', 'signup', '', '1', '1', '', '', '', '2022-01-24 07:21:07', '2', ''),
(795, 'Blog', 'blog', '', '1', '1', '', '', '', '2022-01-24 07:21:07', '2', '');

-- --------------------------------------------------------

--
-- Table structure for table `panel_categories`
--

CREATE TABLE `panel_categories` (
  `id` int(11) NOT NULL,
  `name` text CHARACTER SET utf8mb4,
  `status` enum('0','1') NOT NULL DEFAULT '1' COMMENT '1 -> ENABLE, 0 -> DISABLE'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `panel_info`
--

CREATE TABLE `panel_info` (
  `panel_id` int(11) NOT NULL,
  `panel_domain` text COLLATE utf8_unicode_ci NOT NULL,
  `panel_plan` text COLLATE utf8_unicode_ci NOT NULL,
  `panel_status` enum('Pending','Active','Frozen','Suspended') COLLATE utf8_unicode_ci NOT NULL,
  `panel_orders` int(11) NOT NULL,
  `panel_thismonthorders` int(11) NOT NULL,
  `date_created` datetime NOT NULL,
  `api_key` varchar(225) COLLATE utf8_unicode_ci NOT NULL,
  `renewal_date` datetime NOT NULL,
  `panel_type` enum('Child','Main') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Main'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `panel_info`
--

INSERT INTO `panel_info` (`panel_id`, `panel_domain`, `panel_plan`, `panel_status`, `panel_orders`, `panel_thismonthorders`, `date_created`, `api_key`, `renewal_date`, `panel_type`) VALUES
(1, 'yourpanel.com', 'A', 'Active', 1393, 1393, '2022-01-24 10:58:08', 'b1fbedd6f1266a8990bf648919068680', '2025-02-23 10:58:08', 'Main');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `client_balance` decimal(15,2) NOT NULL DEFAULT '0.00',
  `payment_amount` decimal(15,4) NOT NULL,
  `payment_privatecode` double DEFAULT NULL,
  `payment_method` int(11) NOT NULL,
  `payment_status` enum('1','2','3') NOT NULL DEFAULT '1',
  `payment_delivery` enum('1','2') NOT NULL DEFAULT '1',
  `payment_note` varchar(255) NOT NULL DEFAULT 'No',
  `payment_mode` enum('Manuel','Otomatik','Auto') NOT NULL DEFAULT 'Otomatik',
  `payment_create_date` datetime NOT NULL,
  `payment_update_date` datetime NOT NULL,
  `payment_ip` varchar(225) NOT NULL,
  `payment_extra` text NOT NULL,
  `payment_bank` int(11) NOT NULL,
  `t_id` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `client_id`, `client_balance`, `payment_amount`, `payment_privatecode`, `payment_method`, `payment_status`, `payment_delivery`, `payment_note`, `payment_mode`, `payment_create_date`, `payment_update_date`, `payment_ip`, `payment_extra`, `payment_bank`, `t_id`) VALUES
(1, 1, '0.00', '100.0000', NULL, 8, '1', '1', 'No', '', '2022-08-12 18:08:02', '0000-00-00 00:00:00', '2409:4064:2e94:8230::1949:9914, 172.70.183.166', '1660307882', 0, NULL),
(2, 5, '0.00', '20.0000', NULL, 1, '1', '1', 'No', 'Auto', '2022-12-13 22:23:28', '0000-00-00 00:00:00', '49.42.65.47', '9bf8ded2e99416b3044d7111bafd4e4f', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `payments_bonus`
--

CREATE TABLE `payments_bonus` (
  `bonus_id` int(11) NOT NULL,
  `bonus_method` int(11) NOT NULL,
  `bonus_from` double NOT NULL,
  `bonus_amount` double NOT NULL,
  `bonus_type` enum('1','2') NOT NULL DEFAULT '2'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `payment_methods`
--

CREATE TABLE `payment_methods` (
  `id` int(11) NOT NULL,
  `method_name` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `method_get` varchar(225) NOT NULL,
  `method_min` double NOT NULL,
  `method_max` double NOT NULL,
  `method_type` enum('1','2') NOT NULL DEFAULT '2' COMMENT '2 -> ON, 1 -> OFF	',
  `method_extras` text NOT NULL,
  `method_line` double NOT NULL,
  `nouse` enum('1','2') NOT NULL DEFAULT '2',
  `content` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `payment_methods`
--

INSERT INTO `payment_methods` (`id`, `method_name`, `method_get`, `method_min`, `method_max`, `method_type`, `method_extras`, `method_line`, `nouse`, `content`) VALUES
(1, 'Paypal', 'paypal', 10, 10000, '2', '{\"method_type\":\"2\",\"name\":\"Paypal ( USD ) ( International Payments ) [ 10% Charge ]\",\"min\":\"10\",\"max\":\"10000\",\"client_id\":\"AR3wtI3dxA0qU2dme-kQdC6csRL4whF8SNWzJ2jilchyZvQsBJ7URF4UqktveDp67guIenYYX-e0zuCz\",\"client_secret\":\"EMFtatHjrBMf9EYcec0WZqKwGwO2aum03w62b9tZZWPB2G__WoFuBMkMu0z97NR8ooRJNXR0FqrtagrD\",\"fee\":\"10\"}', 5, '2', 'hello'),
(2, 'Stripe', 'stripe', 1, 100, '1', '{\"method_type\":\"2\",\"name\":\"Stripe\",\"min\":\"1\",\"max\":\"100\",\"stripe_publishable_key\":\"pk_live_51HiUnRLjkQAtcIW0F983imoO8qhftSSMSj7oB9xTjGHB51su6vnuDmGNs5l2NNZz1XE1Ogf1svxqjtdasRYr3atk00wEAHHKNT\",\"stripe_secret_key\":\"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\",\"stripe_webhooks_secret\":\"whsec_gSvhMz0eOIOTk5S9uzzzDgpHeclOmiDe\",\"fee\":\"10\",\"currency\":\"USD\"}', 8, '2', ''),
(3, 'Shopier', 'shopier', 5, 0, '1', '{\"method_type\":\"1\",\"name\":\"Kredi \\/ Banka Kart\\u0131 ile \\u00d6de\",\"min\":\"5\",\"max\":\"0\",\"apiKey\":\"\",\"apiSecret\":\"\",\"website_index\":\"1\",\"processing_fee\":\"1\",\"fee\":\"10\",\"currency\":\"USD\"}', 9, '2', ''),
(5, 'Paywant', 'paywant', 1, 0, '1', '{\"method_type\":\"1\",\"name\":\"Paywant\",\"min\":\"1\",\"max\":\"0\",\"apiKey\":\"\",\"apiSecret\":\"\",\"fee\":\"0\",\"currency\":\"USD\",\"commissionType\":\"2\",\"payment_type\":[\"1\",\"2\",\"3\"]}', 10, '2', ''),
(7, 'PayTR', 'paytr', 1, 0, '1', '{\"method_type\":\"1\",\"name\":\"Paytr\",\"min\":\"1\",\"max\":\"0\",\"merchant_id\":\"\",\"merchant_key\":\"\",\"merchant_salt\":\"\",\"fee\":\"0\",\"currency\":\"USD\"}', 11, '2', ''),
(8, 'Coinpayments', 'coinpayments', 10, 10000, '2', '{\"method_type\":\"2\",\"name\":\"CoinPayments ( Cryptocurrency )\",\"min\":\"10\",\"max\":\"10000\",\"coinpayments_public_key\":\"5a6f3154ddf28c2017df7ad00ce5c1f2b872822beb1ed32f52e0009a2425ecfd\",\"coinpayments_private_key\":\"da16CB5D8Ce6d90eD7181b5907F2103739ef0D5dbF591Ddf22d8f93649170E2F\",\"coinpayments_currency\":\"BTC\",\"merchant_id\":\"db74662404abc41263c87ed221718ce3\",\"ipn_secret\":\"5566\",\"fee\":\"0\",\"currency\":\"USD\"}', 6, '2', ''),
(9, '2checkout', '2checkout', 1, 0, '1', '{\"method_type\":\"1\",\"name\":\"2checkout\",\"min\":\"1\",\"max\":\"0\",\"seller_id\":\"\",\"private_key\":\"\",\"fee\":\"1\",\"currency\":\"USD\"}', 12, '2', ''),
(10, 'Payoneer', 'payoneer', 1, 0, '1', '{\"method_type\":\"2\",\"name\":\"Payoneer\",\"email\":\"fazilakbulut@outlook.com\"}', 13, '2', ''),
(11, 'Mollie', 'mollie', 1, 0, '1', '{\"method_type\":\"1\",\"name\":\"Mollie\",\"min\":\"1\",\"max\":\"0\",\"live_api_key\":\"\",\"fee\":\"0\",\"currency\":\"USD\"}', 14, '2', ''),
(12, 'PayTM', 'paytm', 10, 100000, '2', '{\"method_type\":\"2\",\"name\":\"PayTM ( INR )( UPI \\/ NET BANKING \\/ DEBIT \\/ CREDIT CARD)\",\"min\":\"10\",\"max\":\"100000\",\"merchant_key\":\"IR6iRT5L0tOxBte4\",\"merchant_mid\":\"gVkWqH50536759745964\",\"merchant_website\":\"DEFAULT\",\"fee\":\"0\",\"currency\":\"\"}', 1, '2', ''),
(13, 'Instamojo', 'instamojo', 0, 0, '1', '{\"method_type\":\"2\",\"name\":\"Instamojo\",\"min\":\"0\",\"max\":\"0\",\"api_key\":\"a2bdf5035c16ad6db389caeb5ceb5273\",\"live_auth_token_key\":\"81ef2affdc5ecfde9b88b13e1cd67cd8\",\"fee\":\"0\",\"currency\":\"INR\"}', 15, '2', ''),
(14, 'Paytm Business', 'paytmqr', 10, 1000000, '2', '{\"method_type\":\"2\",\"name\":\"PayTM QR (5% Bonus From 2000rs)\",\"min\":\"10\",\"max\":\"1000000\",\"merchant_key\":\"https:\\/\\/i.imgur.com\\/mlAI1qX.png\",\"merchant_mid\":\"HYJEZD46937702834501\",\"merchant_website\":\"DEFAULT\",\"fee\":\"0\"}', 4, '2', ''),
(15, 'Razorpay', 'razorpay', 1, 0, '1', '{\"method_type\":\"1\",\"name\":\"Razorpay\",\"min\":\"1\",\"max\":\"0\",\"api_key\":\"0\",\"api_secret_key\":\"0\",\"fee\":\"0\",\"currency\":\"INR\"}', 16, '2', ''),
(16, 'Iyzico', 'iyzico', 1, 0, '1', '{\"method_type\":\"1\",\"name\":\"Iyzico\",\"min\":\"1\",\"max\":\"0\",\"api_key\":\"0\",\"api_secret_key\":\"0\",\"fee\":\"0\",\"currency\":\"USD\"}', 17, '2', ''),
(17, 'Authorize.net', 'authorize-net', 1, 0, '1', '{\"method_type\":\"1\",\"name\":\"Authorize.net\",\"min\":\"1\",\"max\":\"0\",\"api_login_id\":\"0\",\"secret_transaction_key\":\"0\",\"fee\":\"0\",\"currency\":\"USD\"}', 18, '2', ''),
(20, 'Ravepay', 'ravepay', 1, 0, '1', '{\"method_type\":\"1\",\"name\":\"Ravepay\",\"min\":\"1\",\"max\":\"0\",\"public_api_key\":\"0\",\"secret_api_key\":\"0\",\"fee\":\"0\",\"currency\":\"USD\"}', 20, '2', ''),
(21, 'Pagseguro', 'pagseguro', 1, 0, '1', '{\"method_type\":\"1\",\"name\":\"Pagseguro\",\"min\":\"1\",\"max\":\"0\",\"email_id\":\"0\",\"live_production_token\":\"0\",\"fee\":\"0\",\"currency\":\"USD\"}', 21, '2', ''),
(22, 'Cashmaal', 'Cashmaal', 10, 10000, '2', '{\"method_type\":\"2\",\"name\":\"CashMaal (USD)(JAZZCASH)(EASYPAISA)\",\"min\":\"10\",\"max\":\"10000\",\"web_id\":\"5396\",\"fee\":\"0\",\"currency\":\"USD\"}', 7, '2', ''),
(25, 'Refer & earn', 'refer', 0, 0, '1', '{\"method_type\":\"2\",\"name\":\"Do Not Use\",\"min\":\"1\",\"max\":\"10000\",\"merchant_key\":\"P#n%aKfB3&DRAMqH\",\"merchant_mid\":\"DBWvgX98800736620578\",\"merchant_website\":\"DEFAULT\",\"fee\":\"0\",\"currency\":\"\"}', 25, '1', ''),
(26, 'payumoney', 'payumoney', 10, 0, '1', '{\"method_type\":\"2\",\"name\":\"Payumoney\",\"min\":\"10\",\"max\":\"0\",\"merchant_key\":\"Mv4ctvrc\",\"salt_key\":\"pWUvDRU8CT\",\"fee\":\"10\",\"currency\":\"INR\"}', 19, '2', ''),
(30, 'Freebalance', 'Freebalance', 1, 0, '1', '{\"method_type\":\"1\",\"name\":\"Freebalance\",\"min\":\"1\",\"max\":\"0\",\"merchant_id\":\"\",\"merchant_key\":\"\",\"merchant_salt\":\"\",\"fee\":\"0\"}', 30, '1', ''),
(31, 'Perfect Money', 'perfectmoney', 5, 0, '2', '{\"method_type\":\"2\",\"name\":\"Perfect Money ( USD ) (MIN 5)\",\"min\":\"5\",\"max\":\"0\",\"passphrase\":\"Manbir25@\",\"usd\":\"U31731375\",\"merchant_website\":\"Viralsmmpanel.com\",\"fee\":\"0\"}', 2, '2', ''),
(32, 'Coinbase', 'Coinbase', 1, 0, '2', '{\"method_type\":\"1\",\"name\":\"Coinbase ( Cryptocurrency )\",\"min\":\"1\",\"max\":\"0\",\"api_key\":\"\",\"webhook_api\":\"\",\"fee\":\"0\"}', 22, '2', ''),
(33, 'Webmoney', 'Webmoney', 1, 0, '1', '{\"method_type\":\"1\",\"name\":\"Webmoney\",\"min\":\"1\",\"max\":\"0\",\"wmid\":\"\",\"purse\":\"\",\"fee\":\"0\"}', 23, '2', ''),
(34, 'UnitPay', 'UnityPay', 1, 0, '1', '{\"method_type\":\"1\",\"name\":\"UnitPay\",\"min\":\"1\",\"max\":\"0\",\"secret_key\":\"\",\"reg_email\":\"\",\"fee\":\"0\"}', 24, '2', ''),
(35, 'Payeer', 'payeer', 10, 0, '2', '{\"method_type\":\"2\",\"name\":\"Payeer ( Paypal + Cryptocurrency + Skrill + Debit\\/Credit Cards + Bank + and more)\",\"min\":\"10\",\"max\":\"0\",\"client_secret\":\"NmjYQjAhbv0SFvoj\",\"m_shop\":\"1600076082\"}', 3, '2', '');

-- --------------------------------------------------------

--
-- Table structure for table `payment_methodsold`
--

CREATE TABLE `payment_methodsold` (
  `id` int(11) NOT NULL,
  `method_name` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `method_get` varchar(225) NOT NULL,
  `method_min` double NOT NULL,
  `method_max` double NOT NULL,
  `method_type` enum('1','2') NOT NULL DEFAULT '2' COMMENT '2 -> ON, 1 -> OFF	',
  `method_extras` text NOT NULL,
  `method_line` double NOT NULL,
  `nouse` enum('1','2') NOT NULL DEFAULT '2'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `payment_methodsold`
--

INSERT INTO `payment_methodsold` (`id`, `method_name`, `method_get`, `method_min`, `method_max`, `method_type`, `method_extras`, `method_line`, `nouse`) VALUES
(1, 'Paypal', 'paypal', 10, 10000, '2', '{\"method_type\":\"2\",\"name\":\"Paypal ( USD ) ( International Payments ) [ 10% Charge ]\",\"min\":\"10\",\"max\":\"10000\",\"client_id\":\"AWWRCH4eG0dDMY_84cDXJVKVsBGSzJpnezbgAB4Qm49cTQ2dJwZWMaWzNAbUv4ojUunW-pgicoYTMA0l\",\"client_secret\":\"EMiHDg3EejaX_ns8h3ybEkgBcm_mbFfPoK_EeNyW_UGX_LJlKxa3lpW9nDf7-gRrQMV1kyUWS1J48NxC\",\"fee\":\"10\"}', 3, '2'),
(2, 'Stripe', 'stripe', 1, 100, '1', '{\"method_type\":\"2\",\"name\":\"Stripe\",\"min\":\"1\",\"max\":\"100\",\"stripe_publishable_key\":\"pk_live_51HiUnRLjkQAtcIW0F983imoO8qhftSSMSj7oB9xTjGHB51su6vnuDmGNs5l2NNZz1XE1Ogf1svxqjtdasRYr3atk00wEAHHKNT\",\"stripe_secret_key\":\"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\",\"stripe_webhooks_secret\":\"whsec_gSvhMz0eOIOTk5S9uzzzDgpHeclOmiDe\",\"fee\":\"10\",\"currency\":\"USD\"}', 4, '2'),
(3, 'Shopier', 'shopier', 5, 0, '1', '{\"method_type\":\"1\",\"name\":\"Kredi \\/ Banka Kart\\u0131 ile \\u00d6de\",\"min\":\"5\",\"max\":\"0\",\"apiKey\":\"\",\"apiSecret\":\"\",\"website_index\":\"1\",\"processing_fee\":\"1\",\"fee\":\"10\",\"currency\":\"USD\"}', 5, '2'),
(5, 'Paywant', 'paywant', 1, 0, '1', '{\"method_type\":\"1\",\"name\":\"Paywant\",\"min\":\"1\",\"max\":\"0\",\"apiKey\":\"\",\"apiSecret\":\"\",\"fee\":\"0\",\"currency\":\"USD\",\"commissionType\":\"2\",\"payment_type\":[\"1\",\"2\",\"3\"]}', 6, '2'),
(7, 'PayTR', 'paytr', 1, 0, '1', '{\"method_type\":\"1\",\"name\":\"Paytr\",\"min\":\"1\",\"max\":\"0\",\"merchant_id\":\"\",\"merchant_key\":\"\",\"merchant_salt\":\"\",\"fee\":\"0\",\"currency\":\"USD\"}', 7, '2'),
(8, 'Coinpayments', 'coinpayments', 1, 0, '1', '{\"method_type\":\"1\",\"name\":\"Coinpayments\",\"min\":\"1\",\"max\":\"0\",\"coinpayments_public_key\":\"\",\"coinpayments_private_key\":\"\",\"coinpayments_currency\":\"LTCT\",\"merchant_id\":\"\",\"ipn_secret\":\"\",\"fee\":\"0\",\"currency\":\"USD\"}', 8, '2'),
(9, '2checkout', '2checkout', 1, 0, '1', '{\"method_type\":\"1\",\"name\":\"2checkout\",\"min\":\"1\",\"max\":\"0\",\"seller_id\":\"\",\"private_key\":\"\",\"fee\":\"1\",\"currency\":\"USD\"}', 9, '2'),
(10, 'Payoneer', 'payoneer', 1, 0, '1', '{\"method_type\":\"2\",\"name\":\"Payoneer\",\"email\":\"fazilakbulut@outlook.com\"}', 10, '2'),
(11, 'Mollie', 'mollie', 1, 0, '1', '{\"method_type\":\"1\",\"name\":\"Mollie\",\"min\":\"1\",\"max\":\"0\",\"live_api_key\":\"\",\"fee\":\"0\",\"currency\":\"USD\"}', 11, '2'),
(12, 'PayTM', 'paytm', 10, 100000, '2', '{\"method_type\":\"2\",\"name\":\"PayTM ( INR )( UPI \\/ NET BANKING \\/ DEBIT \\/ CREDIT CARD)\",\"min\":\"10\",\"max\":\"100000\",\"merchant_key\":\"IR6iRT5L0tOxBte4\",\"merchant_mid\":\"gVkWqH50536759745964\",\"merchant_website\":\"DEFAULT\",\"fee\":\"0\",\"currency\":\"\"}', 2, '2'),
(13, 'Instamojo', 'instamojo', 0, 0, '1', '{\"method_type\":\"2\",\"name\":\"Instamojo\",\"min\":\"0\",\"max\":\"0\",\"api_key\":\"a2bdf5035c16ad6db389caeb5ceb5273\",\"live_auth_token_key\":\"81ef2affdc5ecfde9b88b13e1cd67cd8\",\"fee\":\"0\",\"currency\":\"INR\"}', 12, '2'),
(14, 'Paytm Business', 'paytmqr', 10, 1000000, '2', '{\"method_type\":\"2\",\"name\":\"PayTM QR (5% Bonus From 2000rs)\",\"min\":\"10\",\"max\":\"1000000\",\"merchant_key\":\"https:\\/\\/i.imgur.com\\/mlAI1qX.png\",\"merchant_mid\":\"HYJEZD46937702834501\",\"merchant_website\":\"DEFAULT\",\"fee\":\"0\"}', 1, '2'),
(15, 'Razorpay', 'razorpay', 1, 0, '1', '{\"method_type\":\"1\",\"name\":\"Razorpay\",\"min\":\"1\",\"max\":\"0\",\"api_key\":\"0\",\"api_secret_key\":\"0\",\"fee\":\"0\",\"currency\":\"INR\"}', 13, '2'),
(16, 'Iyzico', 'iyzico', 1, 0, '1', '{\"method_type\":\"1\",\"name\":\"Iyzico\",\"min\":\"1\",\"max\":\"0\",\"api_key\":\"0\",\"api_secret_key\":\"0\",\"fee\":\"0\",\"currency\":\"USD\"}', 14, '2'),
(17, 'Authorize.net', 'authorize-net', 1, 0, '1', '{\"method_type\":\"1\",\"name\":\"Authorize.net\",\"min\":\"1\",\"max\":\"0\",\"api_login_id\":\"0\",\"secret_transaction_key\":\"0\",\"fee\":\"0\",\"currency\":\"USD\"}', 15, '2'),
(20, 'Ravepay', 'ravepay', 1, 0, '1', '{\"method_type\":\"1\",\"name\":\"Ravepay\",\"min\":\"1\",\"max\":\"0\",\"public_api_key\":\"0\",\"secret_api_key\":\"0\",\"fee\":\"0\",\"currency\":\"USD\"}', 17, '2'),
(21, 'Pagseguro', 'pagseguro', 1, 0, '1', '{\"method_type\":\"1\",\"name\":\"Pagseguro\",\"min\":\"1\",\"max\":\"0\",\"email_id\":\"0\",\"live_production_token\":\"0\",\"fee\":\"0\",\"currency\":\"USD\"}', 18, '2'),
(22, 'Cashmaal', 'Cashmaal', 1, 10000, '2', '{\"method_type\":\"2\",\"name\":\"CashMaal (USD)(JAZZCASH)(EASYPAISA)\",\"min\":\"1\",\"max\":\"10000\",\"web_id\":\"5396\",\"fee\":\"0\",\"currency\":\"USD\"}', 19, '2'),
(25, 'Refer & earn', 'refer', 0, 0, '1', '{\"method_type\":\"2\",\"name\":\"Do Not Use\",\"min\":\"1\",\"max\":\"10000\",\"merchant_key\":\"P#n%aKfB3&DRAMqH\",\"merchant_mid\":\"DBWvgX98800736620578\",\"merchant_website\":\"DEFAULT\",\"fee\":\"0\",\"currency\":\"\"}', 25, '1'),
(26, 'payumoney', 'payumoney', 10, 0, '1', '{\"method_type\":\"2\",\"name\":\"Payumoney\",\"min\":\"10\",\"max\":\"0\",\"merchant_key\":\"Mv4ctvrc\",\"salt_key\":\"pWUvDRU8CT\",\"fee\":\"10\",\"currency\":\"INR\"}', 16, '2'),
(30, 'Freebalance', 'Freebalance', 1, 0, '1', '{\"method_type\":\"1\",\"name\":\"Freebalance\",\"min\":\"1\",\"max\":\"0\",\"merchant_id\":\"\",\"merchant_key\":\"\",\"merchant_salt\":\"\",\"fee\":\"0\"}', 30, '1');

-- --------------------------------------------------------

--
-- Table structure for table `referral`
--

CREATE TABLE `referral` (
  `referral_id` int(11) NOT NULL,
  `referral_client_id` int(11) NOT NULL,
  `referral_clicks` double NOT NULL DEFAULT '0',
  `referral_sign_up` double NOT NULL DEFAULT '0',
  `referral_totalFunds_byReffered` double NOT NULL DEFAULT '0',
  `referral_earned_commision` double DEFAULT '0',
  `referral_requested_commision` varchar(225) DEFAULT '0',
  `referral_total_commision` double DEFAULT '0',
  `referral_status` enum('1','2') NOT NULL DEFAULT '1',
  `referral_code` text NOT NULL,
  `referral_rejected_commision` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `referral`
--

INSERT INTO `referral` (`referral_id`, `referral_client_id`, `referral_clicks`, `referral_sign_up`, `referral_totalFunds_byReffered`, `referral_earned_commision`, `referral_requested_commision`, `referral_total_commision`, `referral_status`, `referral_code`, `referral_rejected_commision`) VALUES
(1, 1, 0, 0, 0, 0, '0', 0, '1', '463a1d', 0),
(2, 2, 0, 0, 0, 0, '0', 0, '1', 'bce776', 0),
(3, 3, 0, 0, 0, 0, '0', 0, '1', '46b934', 0),
(4, 4, 0, 0, 0, 0, '0', 0, '1', 'd3d362', 0),
(5, 5, 0, 0, 0, 0, '0', 0, '1', '1e1f7e', 0),
(6, 6, 0, 0, 0, 0, '0', 0, '1', '961764', 0),
(7, 7, 0, 0, 0, 0, '0', 0, '1', 'bbc86e', 0),
(8, 8, 0, 0, 0, 0, '0', 0, '1', '447329', 0),
(9, 9, 0, 0, 0, 0, '0', 0, '1', '80ca40', 0),
(10, 10, 0, 0, 0, 0, '0', 0, '1', '2650f3', 0),
(11, 11, 0, 0, 0, 0, '0', 0, '1', 'dae15f', 0);

-- --------------------------------------------------------

--
-- Table structure for table `referral_payouts`
--

CREATE TABLE `referral_payouts` (
  `r_p_id` int(11) NOT NULL,
  `r_p_code` text NOT NULL,
  `r_p_status` enum('1','2','3','4','0') NOT NULL DEFAULT '0',
  `r_p_amount_requested` double NOT NULL,
  `r_p_requested_at` datetime NOT NULL,
  `r_p_updated_at` datetime NOT NULL,
  `client_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `refill_status`
--

CREATE TABLE `refill_status` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `refill_apiid` int(11) DEFAULT NULL,
  `order_url` text NOT NULL,
  `creation_date` datetime DEFAULT NULL,
  `ending_date` date DEFAULT NULL,
  `service_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `refill_status` enum('Pending','Refilling','Completed','Rejected','Error') DEFAULT 'Pending',
  `order_apiid` int(11) DEFAULT '0',
  `refill_response` text,
  `refill_where` enum('site','api') DEFAULT 'site'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `serviceapi_alert`
--

CREATE TABLE `serviceapi_alert` (
  `id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `serviceapi_alert` text NOT NULL,
  `servicealert_extra` text NOT NULL,
  `servicealert_date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `service_id` int(11) NOT NULL,
  `service_api` int(11) NOT NULL DEFAULT '0',
  `api_service` int(11) NOT NULL DEFAULT '0',
  `api_servicetype` enum('1','2') NOT NULL DEFAULT '2',
  `api_detail` text NOT NULL,
  `category_id` int(11) NOT NULL,
  `service_line` double NOT NULL,
  `service_type` enum('1','2') NOT NULL DEFAULT '2',
  `service_package` enum('1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17') NOT NULL,
  `service_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `service_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `service_price` varchar(225) NOT NULL,
  `service_min` double NOT NULL,
  `service_max` double NOT NULL,
  `service_dripfeed` enum('1','2') NOT NULL DEFAULT '1',
  `service_autotime` double NOT NULL DEFAULT '0',
  `service_autopost` double NOT NULL DEFAULT '0',
  `service_speed` enum('1','2','3','4') NOT NULL,
  `want_username` enum('1','2') NOT NULL DEFAULT '1',
  `service_secret` enum('1','2') NOT NULL DEFAULT '2',
  `price_type` enum('normal','percent','amount') NOT NULL DEFAULT 'normal',
  `price_cal` text,
  `instagram_second` enum('1','2') NOT NULL DEFAULT '2',
  `start_count` enum('none','instagram_follower','instagram_photo','') NOT NULL,
  `instagram_private` enum('1','2') NOT NULL,
  `name_lang` varchar(225) DEFAULT 'en',
  `description_lang` text,
  `time_lang` varchar(225) NOT NULL DEFAULT 'Not enough data',
  `time` varchar(225) NOT NULL DEFAULT 'Not enough data',
  `cancelbutton` enum('1','2') NOT NULL DEFAULT '2' COMMENT '1 -> ON, 2 -> OFF',
  `show_refill` enum('true','false') NOT NULL DEFAULT 'false',
  `service_profit` varchar(225) NOT NULL,
  `refill_days` varchar(225) NOT NULL DEFAULT '30',
  `refill_hours` varchar(225) NOT NULL DEFAULT '24',
  `avg_days` int(11) NOT NULL,
  `avg_hours` int(11) NOT NULL,
  `avg_minutes` int(11) NOT NULL,
  `avg_many` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`service_id`, `service_api`, `api_service`, `api_servicetype`, `api_detail`, `category_id`, `service_line`, `service_type`, `service_package`, `service_name`, `service_description`, `service_price`, `service_min`, `service_max`, `service_dripfeed`, `service_autotime`, `service_autopost`, `service_speed`, `want_username`, `service_secret`, `price_type`, `price_cal`, `instagram_second`, `start_count`, `instagram_private`, `name_lang`, `description_lang`, `time_lang`, `time`, `cancelbutton`, `show_refill`, `service_profit`, `refill_days`, `refill_hours`, `avg_days`, `avg_hours`, `avg_minutes`, `avg_many`) VALUES
(1, 1, 2518, '2', '{\"min\":\"100\",\"max\":\"1500000\",\"rate\":\"0.6\",\"refill\":null,\"currency\":\"USD\"}', 1, 1, '2', '1', 'Instagram💎 Pure Indian followers 🇮🇳[ Non-drop ] [ Lifetime guarantee] [ High quality Profiles  💎', '', '0.7200', 100, 1500000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram\\ud83d\\udc8e Pure Indian followers \\ud83c\\uddee\\ud83c\\uddf3[ Non-drop ] [ Lifetime guarantee] [ High quality Profiles  \\ud83d\\udc8e\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'true', '20', '30', '24', 0, 0, 0, 0),
(2, 1, 2523, '2', '{\"min\":\"100\",\"max\":\"5000000\",\"rate\":\"0.185\",\"refill\":null,\"currency\":\"USD\"}', 1, 1, '2', '1', 'Instagram Followers Non-Drop [ 365 refil button ✅] [ 15-20 post ] [ 0-5% drop ☔ ] ', '', '0.2220', 100, 5000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Followers Non-Drop [ 365 refil button \\u2705] [ 15-20 post ] [ 0-5% drop \\u2614 ] \"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(3, 1, 2516, '2', '{\"min\":\"100\",\"max\":\"1000000000\",\"rate\":\"0.0016\",\"refill\":null,\"currency\":\"USD\"}', 1, 1, '2', '1', 'Instagram Reels Views  l Max 1B | Instant [ 💡💡💡[ Our Own service] 👿', '', '0.0019', 100, 1000000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Reels Views  l Max 1B | Instant [ \\ud83d\\udca1\\ud83d\\udca1\\ud83d\\udca1[ Our Own service] \\ud83d\\udc7f\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(4, 1, 2444, '2', '{\"min\":\"10\",\"max\":\"30000\",\"rate\":\"0.072\",\"refill\":null,\"currency\":\"USD\"}', 1, 1, '2', '1', 'Instagram Likes Non drop [ Super fast ⭐🌟] [ Lifetime guarantee] ', '', '0.0864', 10, 30000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Likes Non drop [ Super fast \\u2b50\\ud83c\\udf1f] [ Lifetime guarantee] \"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(5, 1, 2489, '2', '{\"min\":\"100\",\"max\":\"100000000\",\"rate\":\"0.004\",\"refill\":null,\"currency\":\"USD\"}', 1, 1, '2', '1', 'Instagram Video Views l IGTV | REEL l Max 1M | Instant', '', '0.0048', 100, 100000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Video Views l IGTV | REEL l Max 1M | Instant\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(6, 1, 2413, '2', '{\"min\":\"100\",\"max\":\"50000000\",\"rate\":\"0.02\",\"refill\":null,\"currency\":\"USD\"}', 1, 1, '2', '1', 'TikTok - Views Instant [ Emergency server] 100% working ', '', '0.0240', 100, 50000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"TikTok - Views Instant [ Emergency server] 100% working \"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(7, 1, 2546, '2', '{\"min\":\"100\",\"max\":\"50000\",\"rate\":\"0.018\",\"refill\":null,\"currency\":\"USD\"}', 1, 1, '2', '1', 'Instagram Non drop likes💯 [ No-Refil ] [ 100k base]', '', '0.0216', 100, 50000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Non drop likes\\ud83d\\udcaf [ No-Refil ] [ 100k base]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(8, 1, 1075, '2', '{\"min\":\"\",\"max\":\"\",\"rate\":\"3840\",\"refill\":null,\"currency\":\"USD\"}', 2, 1, '2', '2', '[ Instagram Verification (Blue Badge / Blue Tick) ⭐🔥[ All countries ✅ people can apply] [ Read Description 👇 ]', '', '4608.0000', 0, 0, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"[ Instagram Verification (Blue Badge \\/ Blue Tick) \\u2b50\\ud83d\\udd25[ All countries \\u2705 people can apply] [ Read Description \\ud83d\\udc47 ]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(9, 1, 2223, '2', '{\"min\":\"1\",\"max\":\"\",\"rate\":\"49\",\"refill\":null,\"currency\":\"USD\"}', 3, 1, '2', '2', 'Youtube channel  monetize [ 1k subscribe + 4k watchtime ] 7 days complete ', '', '58.8000', 1, 0, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Youtube channel  monetize [ 1k subscribe + 4k watchtime ] 7 days complete \"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(10, 1, 1082, '2', '{\"min\":\"100\",\"max\":\"\",\"rate\":\"553\",\"refill\":null,\"currency\":\"USD\"}', 4, 1, '2', '2', 'Google Adwords Views 1 million Package [ WORLDWIDE ] [ ORGANIC ] ', '', '663.6000', 100, 0, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Google Adwords Views 1 million Package [ WORLDWIDE ] [ ORGANIC ] \"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(11, 1, 2450, '2', '{\"min\":\"1000\",\"max\":\"1000\",\"rate\":\"2.44\",\"refill\":null,\"currency\":\"USD\"}', 5, 1, '2', '2', 'Revenue 3-5 dollar +1k views [ 100%organic and safe ] ', '', '2.9280', 1000, 1000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Revenue 3-5 dollar +1k views [ 100%organic and safe ] \"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(12, 1, 2451, '2', '{\"min\":\"1000\",\"max\":\"\",\"rate\":\"10.99\",\"refill\":null,\"currency\":\"USD\"}', 5, 1, '2', '2', 'Revenue 15-25 dollar +5k views [ 100%organic and safe ] ', '', '13.1880', 1000, 0, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Revenue 15-25 dollar +5k views [ 100%organic and safe ] \"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(13, 1, 2452, '2', '{\"min\":\"1000\",\"max\":\"\",\"rate\":\"21.37\",\"refill\":null,\"currency\":\"USD\"}', 5, 1, '2', '2', 'Revenue  30-50 dollar +10k views [ 100%organic and safe ] ', '', '25.6440', 1000, 0, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Revenue  30-50 dollar +10k views [ 100%organic and safe ] \"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(14, 1, 2453, '2', '{\"min\":\"1000\",\"max\":\"1000\",\"rate\":\"67.16\",\"refill\":null,\"currency\":\"USD\"}', 5, 1, '2', '2', 'Revenue  90-150 dollar +30k views [ 100%organic and safe ] ', '', '80.5920', 1000, 1000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Revenue  90-150 dollar +30k views [ 100%organic and safe ] \"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(15, 1, 2454, '2', '{\"min\":\"1000\",\"max\":\"1000\",\"rate\":\"98.07\",\"refill\":null,\"currency\":\"USD\"}', 5, 1, '2', '2', 'Revenue  150 - 300 dollar +30k views [ 100%organic and safe ] ', '', '117.6840', 1000, 1000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Revenue  150 - 300 dollar +30k views [ 100%organic and safe ] \"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(16, 1, 2503, '2', '{\"min\":\"1\",\"max\":\"1000\",\"rate\":\"34.29\",\"refill\":null,\"currency\":\"USD\"}', 5, 1, '2', '1', '....', '', '41.1480', 1, 1000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"....\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(17, 1, 1116, '2', '{\"min\":\"1000\",\"max\":\"\",\"rate\":\"10.48\",\"refill\":null,\"currency\":\"USD\"}', 6, 1, '2', '2', 'Child panel [ ₹800 only ]  [ per month 200 ₹ rent ] ', '', '12.5760', 1000, 0, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Child panel [ \\u20b9800 only ]  [ per month 200 \\u20b9 rent ] \"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(18, 1, 1816, '2', '{\"min\":\"1000\",\"max\":\"\",\"rate\":\"50.4\",\"refill\":null,\"currency\":\"USD\"}', 6, 1, '2', '2', 'Self panel [  lifetime pack ]  [  Your own website ]  [ Unlock All Features ] ', '', '60.4800', 1000, 0, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Self panel [  lifetime pack ]  [  Your own website ]  [ Unlock All Features ] \"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(19, 1, 2399, '2', '{\"min\":\"\",\"max\":\"\",\"rate\":\"20\",\"refill\":null,\"currency\":\"USD\"}', 6, 1, '2', '2', 'Smm Panel scripts [ All features] Available ', '', '24.0000', 0, 0, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Smm Panel scripts [ All features] Available \"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(20, 1, 2162, '2', '{\"min\":\"1000\",\"max\":\"100000\",\"rate\":\"2.61\",\"refill\":null,\"currency\":\"USD\"}', 7, 1, '2', '1', 'Instagram id reports ❌🚫🚫 [ Half refund if not successful] ', '', '3.1320', 1000, 100000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram id reports \\u274c\\ud83d\\udeab\\ud83d\\udeab [ Half refund if not successful] \"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(21, 1, 954, '2', '{\"min\":\"1000\",\"max\":\"\",\"rate\":\"0.63\",\"refill\":null,\"currency\":\"USD\"}', 8, 1, '2', '2', 'Amazon prime video [ 5 screen ] [ 30 days gurantee]', '', '0.7560', 1000, 0, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Amazon prime video [ 5 screen ] [ 30 days gurantee]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(22, 1, 960, '2', '{\"min\":\"1000\",\"max\":\"\",\"rate\":\"7.38\",\"refill\":null,\"currency\":\"USD\"}', 8, 1, '2', '2', 'Amazon prime video [ 5 screen ] dont use amazon shopping app [ [ 1 year gurantee]', '', '8.8560', 1000, 0, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Amazon prime video [ 5 screen ] dont use amazon shopping app [ [ 1 year gurantee]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(23, 1, 956, '2', '{\"min\":\"1000\",\"max\":\"\",\"rate\":\"0.81\",\"refill\":null,\"currency\":\"USD\"}', 8, 1, '2', '2', 'Youtube premium [ private ] [ 30 days gurantee]', '', '0.9720', 1000, 0, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Youtube premium [ private ] [ 30 days gurantee]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(24, 1, 958, '2', '{\"min\":\"1000\",\"max\":\"\",\"rate\":\"1.84\",\"refill\":null,\"currency\":\"USD\"}', 8, 1, '2', '2', 'Youtube premium 4 months [ on your mail ] [ Fresh mail 💌 required]', '', '2.2080', 1000, 0, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Youtube premium 4 months [ on your mail ] [ Fresh mail \\ud83d\\udc8c required]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(25, 1, 957, '2', '{\"min\":\"1000\",\"max\":\"\",\"rate\":\"4.03\",\"refill\":null,\"currency\":\"USD\"}', 8, 1, '2', '2', 'NETFLIX  [ 30 days gurantee] 4 screen UHD Plan 📝 [ Password Changeable]', '', '4.8360', 1000, 0, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"NETFLIX  [ 30 days gurantee] 4 screen UHD Plan \\ud83d\\udcdd [ Password Changeable]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(26, 1, 959, '2', '{\"min\":\"1000\",\"max\":\"\",\"rate\":\"32.21\",\"refill\":null,\"currency\":\"USD\"}', 8, 1, '2', '2', 'NETFLIX   [ 1 year gurantee]', '', '38.6520', 1000, 0, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"NETFLIX   [ 1 year gurantee]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(27, 1, 955, '2', '{\"min\":\"1000\",\"max\":\"\",\"rate\":\"0.81\",\"refill\":null,\"currency\":\"USD\"}', 8, 1, '2', '2', 'Spotify ', '', '0.9720', 1000, 0, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Spotify \"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(28, 1, 961, '2', '{\"min\":\"1000\",\"max\":\"\",\"rate\":\"8.05\",\"refill\":null,\"currency\":\"USD\"}', 8, 1, '2', '2', 'Timesprime ', '', '9.6600', 1000, 0, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Timesprime \"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(29, 1, 963, '2', '{\"min\":\"1000\",\"max\":\"\",\"rate\":\"1.34\",\"refill\":null,\"currency\":\"USD\"}', 8, 1, '2', '2', 'Spotify 3 MONTHS ', '', '1.6080', 1000, 0, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Spotify 3 MONTHS \"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(30, 1, 962, '2', '{\"min\":\"1000\",\"max\":\"\",\"rate\":\"6.7\",\"refill\":null,\"currency\":\"USD\"}', 8, 1, '2', '2', 'CANVA PRO LIFETIME ', '', '8.0400', 1000, 0, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"CANVA PRO LIFETIME \"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(31, 1, 2385, '2', '{\"min\":\"1000\",\"max\":\"20000\",\"rate\":\"0.14\",\"refill\":null,\"currency\":\"USD\"}', 9, 1, '2', '1', 'Boost 🚀your Instagram account organically [ Enter Your Post link 🔗] ', '', '0.1680', 1000, 20000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Boost \\ud83d\\ude80your Instagram account organically [ Enter Your Post link \\ud83d\\udd17] \"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(32, 1, 2496, '2', '{\"min\":\"100\",\"max\":\"1000000000\",\"rate\":\"0.0024\",\"refill\":null,\"currency\":\"USD\"}', 10, 1, '2', '1', 'Instagram Video Views l IGTV | REEL l Max 1M | Instant', '', '0.0029', 100, 1000000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Video Views l IGTV | REEL l Max 1M | Instant\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(33, 1, 2505, '2', '{\"min\":\"100\",\"max\":\"1000000000\",\"rate\":\"0.0036\",\"refill\":null,\"currency\":\"USD\"}', 10, 1, '2', '1', 'Instagram Video Video Views   IGTV   Reel | Max 10M | Speed 1M/Day | Fastest', '', '0.0043', 100, 1000000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Video Video Views   IGTV   Reel | Max 10M | Speed 1M\\/Day | Fastest\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(34, 1, 2395, '2', '{\"min\":\"100\",\"max\":\"10000000\",\"rate\":\"0.012\",\"refill\":null,\"currency\":\"USD\"}', 10, 1, '2', '1', 'Instagram Reels  Views [ Emergency server ] ☄️☄️', '', '0.0144', 100, 10000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Reels  Views [ Emergency server ] \\u2604\\ufe0f\\u2604\\ufe0f\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(35, 1, 2262, '2', '{\"min\":\"1\",\"max\":\"1\",\"rate\":\"1.2\",\"refill\":null,\"currency\":\"USD\"}', 11, 1, '2', '2', 'Instagram Verified Accounts 1 Followers', '', '1.4400', 1, 1, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Verified Accounts 1 Followers\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(36, 1, 2263, '2', '{\"min\":\"1\",\"max\":\"1\",\"rate\":\"2.064\",\"refill\":null,\"currency\":\"USD\"}', 11, 1, '2', '2', 'Instagram Verified Accounts 2 Followers', '', '2.4768', 1, 1, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Verified Accounts 2 Followers\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(37, 1, 2264, '2', '{\"min\":\"1\",\"max\":\"1\",\"rate\":\"3.108\",\"refill\":null,\"currency\":\"USD\"}', 11, 1, '2', '2', 'Instagram Verified Accounts 3 Followers', '', '3.7296', 1, 1, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Verified Accounts 3 Followers\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(38, 1, 2265, '2', '{\"min\":\"1\",\"max\":\"1\",\"rate\":\"4.812\",\"refill\":null,\"currency\":\"USD\"}', 11, 1, '2', '2', 'Instagram Verified Accounts 4 Followers', '', '5.7744', 1, 1, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Verified Accounts 4 Followers\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(39, 1, 2266, '2', '{\"min\":\"1\",\"max\":\"1\",\"rate\":\"7.32\",\"refill\":null,\"currency\":\"USD\"}', 11, 1, '2', '2', 'Instagram Verified Accounts 5 Followers', '', '8.7840', 1, 1, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Verified Accounts 5 Followers\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(40, 1, 2267, '2', '{\"min\":\"1\",\"max\":\"1\",\"rate\":\"6.12\",\"refill\":null,\"currency\":\"USD\"}', 11, 1, '2', '2', 'Instagram Verified Accounts 6 Followers', '', '7.3440', 1, 1, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Verified Accounts 6 Followers\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(41, 1, 2268, '2', '{\"min\":\"1\",\"max\":\"1\",\"rate\":\"8.4\",\"refill\":null,\"currency\":\"USD\"}', 11, 1, '2', '2', 'Instagram Verified Accounts 7 Followers', '', '10.0800', 1, 1, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Verified Accounts 7 Followers\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(42, 1, 2269, '2', '{\"min\":\"1\",\"max\":\"1\",\"rate\":\"10.512\",\"refill\":null,\"currency\":\"USD\"}', 11, 1, '2', '2', 'Instagram Verified Accounts 10 Followers', '', '12.6144', 1, 1, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Verified Accounts 10 Followers\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(43, 1, 2270, '2', '{\"min\":\"1\",\"max\":\"1\",\"rate\":\"17.928\",\"refill\":null,\"currency\":\"USD\"}', 11, 1, '2', '2', 'Instagram Verified Accounts 15 Followers', '', '21.5136', 1, 1, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Verified Accounts 15 Followers\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(44, 1, 2271, '2', '{\"min\":\"1\",\"max\":\"1\",\"rate\":\"23.856\",\"refill\":null,\"currency\":\"USD\"}', 11, 1, '2', '2', 'Instagram Verified Accounts 20 Followers', '', '28.6272', 1, 1, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Verified Accounts 20 Followers\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(45, 1, 2272, '2', '{\"min\":\"1\",\"max\":\"1\",\"rate\":\"29.784\",\"refill\":null,\"currency\":\"USD\"}', 11, 1, '2', '2', 'Instagram Verified Accounts 25 Followers', '', '35.7408', 1, 1, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Verified Accounts 25 Followers\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(46, 1, 2286, '2', '{\"min\":\"1\",\"max\":\"1000\",\"rate\":\"1.14\",\"refill\":null,\"currency\":\"USD\"}', 11, 1, '2', '4', 'Instagram Verified  Accounts 1 Comment', '', '1.3680', 1, 1000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Verified  Accounts 1 Comment\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(47, 1, 2287, '2', '{\"min\":\"1\",\"max\":\"1000\",\"rate\":\"2.268\",\"refill\":null,\"currency\":\"USD\"}', 11, 1, '2', '4', 'Instagram Verified  Accounts 2 Comment', '', '2.7216', 1, 1000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Verified  Accounts 2 Comment\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(48, 1, 2288, '2', '{\"min\":\"1\",\"max\":\"1\",\"rate\":\"3.396\",\"refill\":null,\"currency\":\"USD\"}', 11, 1, '2', '4', 'Instagram Verified  Accounts 3 Comment', '', '4.0752', 1, 1, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Verified  Accounts 3 Comment\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(49, 1, 2289, '2', '{\"min\":\"1\",\"max\":\"1\",\"rate\":\"4.5\",\"refill\":null,\"currency\":\"USD\"}', 11, 1, '2', '4', 'Instagram Verified  Accounts 4 Comment', '', '5.4000', 1, 1, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Verified  Accounts 4 Comment\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(50, 1, 2290, '2', '{\"min\":\"1\",\"max\":\"1\",\"rate\":\"6\",\"refill\":null,\"currency\":\"USD\"}', 11, 1, '2', '4', 'Instagram Verified  Accounts 5 Comment', '', '7.2000', 1, 1, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Verified  Accounts 5 Comment\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(51, 1, 2291, '2', '{\"min\":\"1\",\"max\":\"1\",\"rate\":\"10.428\",\"refill\":null,\"currency\":\"USD\"}', 11, 1, '2', '4', 'Instagram Verified  Accounts 10 Comment', '', '12.5136', 1, 1, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Verified  Accounts 10 Comment\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(52, 1, 2292, '2', '{\"min\":\"1\",\"max\":\"1\",\"rate\":\"17.16\",\"refill\":null,\"currency\":\"USD\"}', 11, 1, '2', '4', 'Instagram Verified  Accounts 15 Comment', '', '20.5920', 1, 1, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Verified  Accounts 15 Comment\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(53, 1, 2293, '2', '{\"min\":\"1\",\"max\":\"1\",\"rate\":\"26.304\",\"refill\":null,\"currency\":\"USD\"}', 11, 1, '2', '4', 'Instagram Verified  Accounts 20 Comment', '', '31.5648', 1, 1, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Verified  Accounts 20 Comment\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(54, 1, 2517, '2', '{\"min\":\"100\",\"max\":\"1500000\",\"rate\":\"0.6\",\"refill\":null,\"currency\":\"USD\"}', 12, 1, '2', '1', 'Instagram💎 Pure Indian followers 🇮🇳[ Non-drop ] [ Lifetime guarantee] [ High quality Profiles  💎', '', '0.7200', 100, 1500000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram\\ud83d\\udc8e Pure Indian followers \\ud83c\\uddee\\ud83c\\uddf3[ Non-drop ] [ Lifetime guarantee] [ High quality Profiles  \\ud83d\\udc8e\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(55, 1, 2449, '2', '{\"min\":\"50\",\"max\":\"800000\",\"rate\":\"0.48\",\"refill\":null,\"currency\":\"USD\"}', 13, 1, '2', '1', 'Instagram  Followers Mix 🇮🇳 [ Non-Drop ] Lifetime guarantee ', '', '0.5760', 50, 800000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram  Followers Mix \\ud83c\\uddee\\ud83c\\uddf3 [ Non-Drop ] Lifetime guarantee \"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(56, 1, 2497, '2', '{\"min\":\"50\",\"max\":\"800000\",\"rate\":\"0.37\",\"refill\":null,\"currency\":\"USD\"}', 13, 1, '2', '1', 'Instagram Followers | Max 500K | Speed 100K/Day | Lifetime Guaranteed | Drop Ratio : 0% | 𝗥𝗘𝗙𝗜𝗟𝗟 Button Enabled ♻️', '', '0.4440', 50, 800000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Followers | Max 500K | Speed 100K\\/Day | Lifetime Guaranteed | Drop Ratio : 0% | \\ud835\\udde5\\ud835\\uddd8\\ud835\\uddd9\\ud835\\udddc\\ud835\\udddf\\ud835\\udddf Button Enabled \\u267b\\ufe0f\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(57, 1, 2448, '2', '{\"min\":\"20\",\"max\":\"1000000\",\"rate\":\"0.41\",\"refill\":null,\"currency\":\"USD\"}', 14, 1, '2', '1', 'Instagram Followers Non-Drop [1 year refil Guarantee] ♻️🌈🌈', '', '0.4920', 20, 1000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Followers Non-Drop [1 year refil Guarantee] \\u267b\\ufe0f\\ud83c\\udf08\\ud83c\\udf08\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(58, 1, 2493, '2', '{\"min\":\"10\",\"max\":\"10000\",\"rate\":\"0.11\",\"refill\":null,\"currency\":\"USD\"}', 15, 1, '2', '1', 'Instagram Bot Followers [ Own service 👿]', '', '0.1320', 10, 10000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Bot Followers [ Own service \\ud83d\\udc7f]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(59, 1, 2494, '2', '{\"min\":\"100\",\"max\":\"10000\",\"rate\":\"0.13\",\"refill\":null,\"currency\":\"USD\"}', 15, 1, '2', '1', 'Instagram Bot Followers | Max 100K [ Own server ♻️ ] ', '', '0.1560', 100, 10000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Bot Followers | Max 100K [ Own server \\u267b\\ufe0f ] \"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(60, 1, 2190, '2', '{\"min\":\"10\",\"max\":\"10000\",\"rate\":\"0.18\",\"refill\":null,\"currency\":\"USD\"}', 16, 1, '2', '1', 'Instagram Indian 🇮🇳 NON-DROP likes [REAL][80-90% indian profiles]🔥', '', '0.2160', 10, 10000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Indian \\ud83c\\uddee\\ud83c\\uddf3 NON-DROP likes [REAL][80-90% indian profiles]\\ud83d\\udd25\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(61, 1, 2490, '2', '{\"min\":\"10\",\"max\":\"30000\",\"rate\":\"0.12\",\"refill\":null,\"currency\":\"USD\"}', 17, 1, '2', '1', 'Instagram Likes Never Drop ☔⛱️ [ Instant start] ', '', '0.1440', 10, 30000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Likes Never Drop \\u2614\\u26f1\\ufe0f [ Instant start] \"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(62, 1, 2502, '2', '{\"min\":\"10\",\"max\":\"30000\",\"rate\":\"0.06\",\"refill\":null,\"currency\":\"USD\"}', 17, 1, '2', '1', 'Instagram Likes Non - Drop ☔ [ 30 days refil ]', '', '0.0720', 10, 30000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Likes Non - Drop \\u2614 [ 30 days refil ]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(63, 1, 2491, '2', '{\"min\":\"10\",\"max\":\"100000\",\"rate\":\"0.18\",\"refill\":null,\"currency\":\"USD\"}', 17, 1, '2', '1', 'Instagram Likes | Non - Drop ☔⛱️  [ 1 year Guaranteed | ', '', '0.2160', 10, 100000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Likes | Non - Drop \\u2614\\u26f1\\ufe0f  [ 1 year Guaranteed | \"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(64, 1, 2498, '2', '{\"min\":\"10\",\"max\":\"10000\",\"rate\":\"0.96\",\"refill\":null,\"currency\":\"USD\"}', 18, 1, '2', '3', 'Instagram Custom Comment', '', '1.1520', 10, 10000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Custom Comment\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(65, 1, 2499, '2', '{\"min\":\"5\",\"max\":\"10000\",\"rate\":\"0.96\",\"refill\":null,\"currency\":\"USD\"}', 18, 1, '2', '1', 'Instagram Comment Random', '', '1.1520', 5, 10000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Comment Random\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(66, 1, 2277, '2', '{\"min\":\"100\",\"max\":\"5000000\",\"rate\":\"0.0636\",\"refill\":null,\"currency\":\"USD\"}', 19, 1, '2', '1', 'Instagram Impressions', '', '0.0763', 100, 5000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Impressions\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(67, 1, 2278, '2', '{\"min\":\"10\",\"max\":\"10000\",\"rate\":\"0.0768\",\"refill\":null,\"currency\":\"USD\"}', 19, 1, '2', '1', 'Instagram Reach   Impressions', '', '0.0922', 10, 10000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Reach   Impressions\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(68, 1, 2296, '2', '{\"min\":\"100\",\"max\":\"5000\",\"rate\":\"0.02\",\"refill\":null,\"currency\":\"USD\"}', 20, 1, '2', '1', 'Instagram Story Views | All Story Max 1K | 0-15 Minutes', '', '0.0240', 100, 5000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Story Views | All Story Max 1K | 0-15 Minutes\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(69, 1, 2298, '2', '{\"min\":\"100\",\"max\":\"20000\",\"rate\":\"0.09\",\"refill\":null,\"currency\":\"USD\"}', 20, 1, '2', '1', 'Instagram Story Views | All Story Max 20K | 0-15 Minutes', '', '0.1080', 100, 20000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Story Views | All Story Max 20K | 0-15 Minutes\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(70, 1, 2300, '2', '{\"min\":\"5\",\"max\":\"500000\",\"rate\":\"0.036\",\"refill\":null,\"currency\":\"USD\"}', 20, 1, '2', '1', 'Instagram Story Views | All Story  Max 50K | 0-15 Minutes', '', '0.0432', 5, 500000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Story Views | All Story  Max 50K | 0-15 Minutes\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(71, 1, 2301, '2', '{\"min\":\"100\",\"max\":\"400000\",\"rate\":\"0.1\",\"refill\":null,\"currency\":\"USD\"}', 20, 1, '2', '1', 'Instagram Story Views | All Story Max 400K | 0-15 Minutes', '', '0.1200', 100, 400000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Story Views | All Story Max 400K | 0-15 Minutes\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(72, 1, 2302, '2', '{\"min\":\"100\",\"max\":\"1000000\",\"rate\":\"0.276\",\"refill\":null,\"currency\":\"USD\"}', 20, 1, '2', '1', 'Instagran Story Poll Votes | 1. Votes on Answer | Max 10M | Story Link', '', '0.3312', 100, 1000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagran Story Poll Votes | 1. Votes on Answer | Max 10M | Story Link\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(73, 1, 2303, '2', '{\"min\":\"100\",\"max\":\"1000000\",\"rate\":\"0.276\",\"refill\":null,\"currency\":\"USD\"}', 20, 1, '2', '1', 'Instagran Story Poll Votes | 2. Votes on Answer | Max 10M | Story Link', '', '0.3312', 100, 1000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagran Story Poll Votes | 2. Votes on Answer | Max 10M | Story Link\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(74, 1, 2304, '2', '{\"min\":\"100\",\"max\":\"50000\",\"rate\":\"0.396\",\"refill\":null,\"currency\":\"USD\"}', 20, 1, '2', '1', 'Instagran Story Poll Votes | 1. Votes on Answer | Max 50K | Story Link', '', '0.4752', 100, 50000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagran Story Poll Votes | 1. Votes on Answer | Max 50K | Story Link\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(75, 1, 2305, '2', '{\"min\":\"100\",\"max\":\"50000\",\"rate\":\"0.396\",\"refill\":null,\"currency\":\"USD\"}', 20, 1, '2', '1', 'Instagran Story Poll Votes | 2. Votes on Answer | Max 50K | Story Link', '', '0.4752', 100, 50000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagran Story Poll Votes | 2. Votes on Answer | Max 50K | Story Link\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(76, 1, 2306, '2', '{\"min\":\"100\",\"max\":\"1000000\",\"rate\":\"0.276\",\"refill\":null,\"currency\":\"USD\"}', 20, 1, '2', '1', 'Instagram Story Question Answer | 1. Votes on Answer | Max 10M | Story Link', '', '0.3312', 100, 1000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Story Question Answer | 1. Votes on Answer | Max 10M | Story Link\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(77, 1, 2307, '2', '{\"min\":\"100\",\"max\":\"1000000\",\"rate\":\"0.276\",\"refill\":null,\"currency\":\"USD\"}', 20, 1, '2', '1', 'Instagram Story Question Answer | 2. Votes on Answer | Max 10M | Story Link', '', '0.3312', 100, 1000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Story Question Answer | 2. Votes on Answer | Max 10M | Story Link\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(78, 1, 2485, '2', '{\"min\":\"100\",\"max\":\"1000000\",\"rate\":\"0.61\",\"refill\":null,\"currency\":\"USD\"}', 21, 1, '2', '1', 'Youtube Views | Max 1M | Speed 5-10K/Day | Lifetime Guarantee', '', '0.7320', 100, 1000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Youtube Views | Max 1M | Speed 5-10K\\/Day | Lifetime Guarantee\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(79, 1, 2486, '2', '{\"min\":\"100\",\"max\":\"1000000\",\"rate\":\"0.85\",\"refill\":null,\"currency\":\"USD\"}', 21, 1, '2', '1', 'Youtube Views | Max 1M | Speed 50K/Day | Lifetime Guarantee', '', '1.0200', 100, 1000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Youtube Views | Max 1M | Speed 50K\\/Day | Lifetime Guarantee\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(80, 1, 2495, '2', '{\"min\":\"100\",\"max\":\"100000000\",\"rate\":\"0.85\",\"refill\":null,\"currency\":\"USD\"}', 21, 1, '2', '1', 'Youtube Views | 350K/Day | No-Drop | G30 - 100M ', '', '1.0200', 100, 100000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Youtube Views | 350K\\/Day | No-Drop | G30 - 100M \"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(81, 1, 2515, '2', '{\"min\":\"100\",\"max\":\"1000000\",\"rate\":\"0.65\",\"refill\":null,\"currency\":\"USD\"}', 21, 1, '2', '1', 'Youtube Views   2-3% Likes | Max 1M | 5-10K/Day - Lifetime Guarantee', '', '0.7800', 100, 1000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Youtube Views   2-3% Likes | Max 1M | 5-10K\\/Day - Lifetime Guarantee\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(82, 1, 2537, '2', '{\"min\":\"500\",\"max\":\"10000\",\"rate\":\"2\",\"refill\":null,\"currency\":\"USD\"}', 21, 1, '2', '1', 'Youtube Views | Max 1M | Speed 200K/Day | Lifetime Guarantee | Working After Update 🔥', '', '2.4000', 500, 10000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Youtube Views | Max 1M | Speed 200K\\/Day | Lifetime Guarantee | Working After Update \\ud83d\\udd25\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(83, 1, 2483, '2', '{\"min\":\"100\",\"max\":\"1000\",\"rate\":\"0.6\",\"refill\":null,\"currency\":\"USD\"}', 22, 1, '2', '1', 'YouTube Subscribers | Speed: 10-20K/Day | 0-5 Minutes | Drop Rate : 0-100% | No Refill', '', '0.7200', 100, 1000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"YouTube Subscribers | Speed: 10-20K\\/Day | 0-5 Minutes | Drop Rate : 0-100% | No Refill\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(84, 1, 2484, '2', '{\"min\":\"100\",\"max\":\"1000\",\"rate\":\"0.6\",\"refill\":null,\"currency\":\"USD\"}', 22, 1, '2', '1', 'YouTube Subscribers | Speed: 100K/Day | Drop Rate : 0-100% | No Refill', '', '0.7200', 100, 1000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"YouTube Subscribers | Speed: 100K\\/Day | Drop Rate : 0-100% | No Refill\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(85, 1, 2388, '2', '{\"min\":\"100\",\"max\":\"70000\",\"rate\":\"14\",\"refill\":null,\"currency\":\"USD\"}', 23, 1, '2', '1', 'Youtube Subscriber | 100 -200 per  Day | No-Drop | Lifetime guarantee ', '', '16.8000', 100, 70000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Youtube Subscriber | 100 -200 per  Day | No-Drop | Lifetime guarantee \"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(86, 1, 2387, '2', '{\"min\":\"100\",\"max\":\"100000\",\"rate\":\"20\",\"refill\":null,\"currency\":\"USD\"}', 23, 1, '2', '1', 'Youtube - Subscriber [10K per Day Speed ] [Non-Drop] [100% Real] [ LIFETIME GUARANTEE 🌟🌟] ', '', '24.0000', 100, 100000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Youtube - Subscriber [10K per Day Speed ] [Non-Drop] [100% Real] [ LIFETIME GUARANTEE \\ud83c\\udf1f\\ud83c\\udf1f] \"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(87, 1, 1861, '2', '{\"min\":\"100\",\"max\":\"100000\",\"rate\":\"15\",\"refill\":null,\"currency\":\"USD\"}', 23, 1, '2', '1', 'Youtube - Subscriber [500-1k Day] [No-Drop] [100% Real] 🇮🇳 Real users  [ Lifetime refil gurantee ] [ Organic ] [ Recommend ]', '', '18.0000', 100, 100000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Youtube - Subscriber [500-1k Day] [No-Drop] [100% Real] \\ud83c\\uddee\\ud83c\\uddf3 Real users  [ Lifetime refil gurantee ] [ Organic ] [ Recommend ]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(88, 1, 1878, '2', '{\"min\":\"200\",\"max\":\"3000\",\"rate\":\"8\",\"refill\":null,\"currency\":\"USD\"}', 24, 1, '2', '1', 'Youtube - Watchtime [ 120 Mins Video]  [Non Drop] [ Lifetime Guarantee ♻️ ] 500+ per day speed', '', '9.6000', 200, 3000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Youtube - Watchtime [ 120 Mins Video]  [Non Drop] [ Lifetime Guarantee \\u267b\\ufe0f ] 500+ per day speed\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(89, 1, 1855, '2', '{\"min\":\"20\",\"max\":\"500000\",\"rate\":\"0.94\",\"refill\":null,\"currency\":\"USD\"}', 25, 1, '2', '1', 'YouTube - Real Likes [Lifetime Guaranteed] [Non Drop] [Instant Service]', '', '1.1280', 20, 500000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"YouTube - Real Likes [Lifetime Guaranteed] [Non Drop] [Instant Service]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(90, 1, 2487, '2', '{\"min\":\"10\",\"max\":\"50000\",\"rate\":\"0.38\",\"refill\":null,\"currency\":\"USD\"}', 25, 1, '2', '1', 'Youtube Likes | Max 50K | Speed 10-20K/Day | 30 Days Refill ♻️', '', '0.4560', 10, 50000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Youtube Likes | Max 50K | Speed 10-20K\\/Day | 30 Days Refill \\u267b\\ufe0f\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(91, 1, 2506, '2', '{\"min\":\"10\",\"max\":\"50000\",\"rate\":\"0.33\",\"refill\":null,\"currency\":\"USD\"}', 25, 1, '2', '1', 'Youtube Likes | Max 50K | Speed 20K/Day | 30 Days Refill ♻️', '', '0.3960', 10, 50000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Youtube Likes | Max 50K | Speed 20K\\/Day | 30 Days Refill \\u267b\\ufe0f\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(92, 1, 1859, '2', '{\"min\":\"5\",\"max\":\"5000\",\"rate\":\"4.5\",\"refill\":null,\"currency\":\"USD\"}', 26, 1, '2', '3', 'YouTube - Global Custom Comments [Lifetime Guaranteed]', '', '5.4000', 5, 5000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"YouTube - Global Custom Comments [Lifetime Guaranteed]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(93, 1, 1860, '2', '{\"min\":\"10\",\"max\":\"100000\",\"rate\":\"1.275\",\"refill\":null,\"currency\":\"USD\"}', 26, 1, '2', '1', 'YouTube - Comments Likes [Lifetime Guaranteed]', '', '1.5300', 10, 100000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"YouTube - Comments Likes [Lifetime Guaranteed]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(94, 1, 2239, '2', '{\"min\":\"50\",\"max\":\"100000\",\"rate\":\"1.08\",\"refill\":null,\"currency\":\"USD\"}', 27, 1, '2', '1', 'Youtube Live Stream Likes [Instant] [No-Drop]', '', '1.2960', 50, 100000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Youtube Live Stream Likes [Instant] [No-Drop]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(95, 1, 2249, '2', '{\"min\":\"100\",\"max\":\"20000\",\"rate\":\"5\",\"refill\":null,\"currency\":\"USD\"}', 27, 1, '2', '1', 'Youtube Live Stream Views [30 Mins ] [Instant]', '', '6.0000', 100, 20000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Youtube Live Stream Views [30 Mins ] [Instant]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(96, 1, 2250, '2', '{\"min\":\"100\",\"max\":\"20000\",\"rate\":\"6.5\",\"refill\":null,\"currency\":\"USD\"}', 27, 1, '2', '1', 'Youtube Live Stream Views [60 Mins] [Instant]', '', '7.8000', 100, 20000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Youtube Live Stream Views [60 Mins] [Instant]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(97, 1, 2251, '2', '{\"min\":\"100\",\"max\":\"20000\",\"rate\":\"13.6\",\"refill\":null,\"currency\":\"USD\"}', 27, 1, '2', '1', 'Youtube Live Stream Views [3 Hours] [Instant]', '', '16.3200', 100, 20000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Youtube Live Stream Views [3 Hours] [Instant]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(98, 1, 2252, '2', '{\"min\":\"100\",\"max\":\"20000\",\"rate\":\"18.55\",\"refill\":null,\"currency\":\"USD\"}', 27, 1, '2', '1', 'Youtube Live Stream Views [6 Hours] [Instant]', '', '22.2600', 100, 20000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Youtube Live Stream Views [6 Hours] [Instant]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(99, 1, 2253, '2', '{\"min\":\"100\",\"max\":\"20000\",\"rate\":\"26\",\"refill\":null,\"currency\":\"USD\"}', 27, 1, '2', '1', 'Youtube Live Stream Views [12 Hours] [Instant]', '', '31.2000', 100, 20000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Youtube Live Stream Views [12 Hours] [Instant]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(100, 1, 2254, '2', '{\"min\":\"100\",\"max\":\"20000\",\"rate\":\"31\",\"refill\":null,\"currency\":\"USD\"}', 27, 1, '2', '1', 'Youtube Live Stream Views [24 Hours] [Instant]', '', '37.2000', 100, 20000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Youtube Live Stream Views [24 Hours] [Instant]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(101, 1, 2526, '2', '{\"min\":\"10\",\"max\":\"10000\",\"rate\":\"0.36\",\"refill\":null,\"currency\":\"USD\"}', 28, 1, '2', '1', 'Twitter Followers Max 10K | No Refill | Start : 0-10 Minutes', '', '0.4320', 10, 10000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Twitter Followers Max 10K | No Refill | Start : 0-10 Minutes\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(102, 1, 2527, '2', '{\"min\":\"100\",\"max\":\"10000\",\"rate\":\"1.92\",\"refill\":null,\"currency\":\"USD\"}', 28, 1, '2', '1', 'Twitter Followers | Max 10K | Speed 20K/Day | 30 Days Refill Button ♻️', '', '2.3040', 100, 10000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Twitter Followers | Max 10K | Speed 20K\\/Day | 30 Days Refill Button \\u267b\\ufe0f\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(103, 1, 2524, '2', '{\"min\":\"100\",\"max\":\"5000000\",\"rate\":\"0.008\",\"refill\":null,\"currency\":\"USD\"}', 29, 1, '2', '1', 'TikTok Video Views Max 5M', '', '0.0096', 100, 5000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"TikTok Video Views Max 5M\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(104, 1, 1895, '2', '{\"min\":\"100\",\"max\":\"200000\",\"rate\":\"1.968\",\"refill\":null,\"currency\":\"USD\"}', 29, 1, '2', '1', 'TikTok - REAL GLOBAL Followers | R30 |', '', '2.3616', 100, 200000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"TikTok - REAL GLOBAL Followers | R30 |\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(105, 1, 1893, '2', '{\"min\":\"100\",\"max\":\"200000\",\"rate\":\"1.152\",\"refill\":null,\"currency\":\"USD\"}', 29, 1, '2', '1', 'TikTok - REAL GLOBAL Followers', '', '1.3824', 100, 200000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"TikTok - REAL GLOBAL Followers\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(106, 1, 1894, '2', '{\"min\":\"100\",\"max\":\"200000\",\"rate\":\"1.656\",\"refill\":null,\"currency\":\"USD\"}', 29, 1, '2', '1', 'TikTok - REAL GLOBAL Followers | R15 |', '', '1.9872', 100, 200000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"TikTok - REAL GLOBAL Followers | R15 |\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(107, 1, 1896, '2', '{\"min\":\"100\",\"max\":\"20000\",\"rate\":\"0.636\",\"refill\":null,\"currency\":\"USD\"}', 29, 1, '2', '1', 'TikTok - REAL GLOBAL Likes	[FAST]', '', '0.7632', 100, 20000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"TikTok - REAL GLOBAL Likes\\t[FAST]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(108, 1, 1897, '2', '{\"min\":\"100\",\"max\":\"20000\",\"rate\":\"1.5\",\"refill\":null,\"currency\":\"USD\"}', 29, 1, '2', '1', 'TikTok - REAL GLOBAL Likes', '', '1.8000', 100, 20000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"TikTok - REAL GLOBAL Likes\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(109, 1, 2412, '2', '{\"min\":\"10\",\"max\":\"100000\",\"rate\":\"4.5\",\"refill\":null,\"currency\":\"USD\"}', 29, 1, '2', '1', 'TikTok - REAL GLOBAL Followers [FAST] [Day 25K]', '', '5.4000', 10, 100000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"TikTok - REAL GLOBAL Followers [FAST] [Day 25K]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(110, 1, 2414, '2', '{\"min\":\"100\",\"max\":\"200000\",\"rate\":\"1.2\",\"refill\":null,\"currency\":\"USD\"}', 29, 1, '2', '1', 'TikTok Likes | 70-100K/Days | 200K | 0-15 Min - 🚫', '', '1.4400', 100, 200000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"TikTok Likes | 70-100K\\/Days | 200K | 0-15 Min - \\ud83d\\udeab\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0);
INSERT INTO `services` (`service_id`, `service_api`, `api_service`, `api_servicetype`, `api_detail`, `category_id`, `service_line`, `service_type`, `service_package`, `service_name`, `service_description`, `service_price`, `service_min`, `service_max`, `service_dripfeed`, `service_autotime`, `service_autopost`, `service_speed`, `want_username`, `service_secret`, `price_type`, `price_cal`, `instagram_second`, `start_count`, `instagram_private`, `name_lang`, `description_lang`, `time_lang`, `time`, `cancelbutton`, `show_refill`, `service_profit`, `refill_days`, `refill_hours`, `avg_days`, `avg_hours`, `avg_minutes`, `avg_many`) VALUES
(111, 1, 2415, '2', '{\"min\":\"100\",\"max\":\"20000\",\"rate\":\"0.975\",\"refill\":null,\"currency\":\"USD\"}', 29, 1, '2', '1', 'TikTok Likes | 20K/Days | 20K | 0-15 Min - 🚫', '', '1.1700', 100, 20000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"TikTok Likes | 20K\\/Days | 20K | 0-15 Min - \\ud83d\\udeab\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(112, 1, 2416, '2', '{\"min\":\"100\",\"max\":\"20000\",\"rate\":\"0.795\",\"refill\":null,\"currency\":\"USD\"}', 29, 1, '2', '1', 'TikTok Likes | 15K/Days | 20K | 0-15 Min - 🚫', '', '0.9540', 100, 20000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"TikTok Likes | 15K\\/Days | 20K | 0-15 Min - \\ud83d\\udeab\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(113, 1, 2417, '2', '{\"min\":\"100\",\"max\":\"20000\",\"rate\":\"0.75\",\"refill\":null,\"currency\":\"USD\"}', 29, 1, '2', '1', 'TikTok Likes | 10K/Days | 20K | 0-15 Min - 🚫', '', '0.9000', 100, 20000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"TikTok Likes | 10K\\/Days | 20K | 0-15 Min - \\ud83d\\udeab\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(114, 1, 1917, '2', '{\"min\":\"10\",\"max\":\"10000\",\"rate\":\"8.2\",\"refill\":null,\"currency\":\"USD\"}', 30, 1, '2', '1', 'Facebook - Custom Comment [NonDrop]', '', '9.8400', 10, 10000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Facebook - Custom Comment [NonDrop]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(115, 1, 1920, '2', '{\"min\":\"10\",\"max\":\"100000\",\"rate\":\"3.24\",\"refill\":null,\"currency\":\"USD\"}', 30, 1, '2', '1', 'Facebook - Post Comment Likes [Max 100K] [NonDrop] [R30]', '', '3.8880', 10, 100000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Facebook - Post Comment Likes [Max 100K] [NonDrop] [R30]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(116, 1, 2525, '2', '{\"min\":\"100\",\"max\":\"50000\",\"rate\":\"0.17\",\"refill\":null,\"currency\":\"USD\"}', 31, 1, '2', '1', 'Facebook Post/Video Like [ Start 0-30 minute ][ Max 50K ]', '', '0.2040', 100, 50000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Facebook Post\\/Video Like [ Start 0-30 minute ][ Max 50K ]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(117, 1, 2464, '2', '{\"min\":\"100\",\"max\":\"100000\",\"rate\":\"0.97\",\"refill\":null,\"currency\":\"USD\"}', 31, 1, '2', '1', 'Facebook Post Likes [Real] [30 Days Refill][New]', '', '1.1640', 100, 100000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Facebook Post Likes [Real] [30 Days Refill][New]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(118, 1, 2533, '2', '{\"min\":\"1000\",\"max\":\"20000\",\"rate\":\"0.89232\",\"refill\":null,\"currency\":\"USD\"}', 32, 1, '2', '1', 'Facebook Page Likes &amp; Followers | Max 20K', '', '1.0708', 1000, 20000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Facebook Page Likes &amp; Followers | Max 20K\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(119, 1, 2534, '2', '{\"min\":\"1000\",\"max\":\"1000000\",\"rate\":\"3.15996\",\"refill\":null,\"currency\":\"USD\"}', 32, 1, '2', '1', 'Facebook Page Likes &amp; Followers | Max 100K', '', '3.7920', 1000, 1000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Facebook Page Likes &amp; Followers | Max 100K\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(120, 1, 2535, '2', '{\"min\":\"100\",\"max\":\"1000000\",\"rate\":\"1.536\",\"refill\":null,\"currency\":\"USD\"}', 32, 1, '2', '1', 'Facebook Page Likes &amp; Followers | Max 1M', '', '1.8432', 100, 1000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Facebook Page Likes &amp; Followers | Max 1M\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(121, 1, 2536, '2', '{\"min\":\"100\",\"max\":\"500000\",\"rate\":\"1.608\",\"refill\":null,\"currency\":\"USD\"}', 32, 1, '2', '1', 'Facebook Page Likes &amp; Followers | Max 5M', '', '1.9296', 100, 500000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Facebook Page Likes &amp; Followers | Max 5M\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(122, 1, 2455, '2', '{\"min\":\"500\",\"max\":\"100000\",\"rate\":\"1.6\",\"refill\":null,\"currency\":\"USD\"}', 33, 1, '2', '1', 'Facebook Video Views [100-200k/Day] [3-Sec]', '', '1.9200', 500, 100000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Facebook Video Views [100-200k\\/Day] [3-Sec]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(123, 1, 2542, '2', '{\"min\":\"500\",\"max\":\"10000000\",\"rate\":\"0.847\",\"refill\":null,\"currency\":\"USD\"}', 33, 1, '2', '1', 'Facebook Monetizable Views | 3 Seconds Retention | No-Drop | 50K-500K/Day | Instant', '', '1.0164', 500, 10000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Facebook Monetizable Views | 3 Seconds Retention | No-Drop | 50K-500K\\/Day | Instant\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(124, 1, 2543, '2', '{\"min\":\"500\",\"max\":\"10000000\",\"rate\":\"1.034\",\"refill\":null,\"currency\":\"USD\"}', 33, 1, '2', '1', 'Facebook Monetizable Views | 10 Seconds Retention | No-Drop | 50K-500K/Day | Instant', '', '1.2408', 500, 10000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Facebook Monetizable Views | 10 Seconds Retention | No-Drop | 50K-500K\\/Day | Instant\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(125, 1, 2544, '2', '{\"min\":\"500\",\"max\":\"10000000\",\"rate\":\"1.089\",\"refill\":null,\"currency\":\"USD\"}', 33, 1, '2', '1', 'Facebook Monetizable Views | 15 Seconds Retention | No-Drop | 50K-500K/Day | Instant', '', '1.3068', 500, 10000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Facebook Monetizable Views | 15 Seconds Retention | No-Drop | 50K-500K\\/Day | Instant\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(126, 1, 2545, '2', '{\"min\":\"500\",\"max\":\"10000000\",\"rate\":\"1.155\",\"refill\":null,\"currency\":\"USD\"}', 33, 1, '2', '1', 'Facebook Monetizable Views | 30 Seconds Retention | No-Drop | 50K-500K/Day | Instant', '', '1.3860', 500, 10000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Facebook Monetizable Views | 30 Seconds Retention | No-Drop | 50K-500K\\/Day | Instant\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(127, 1, 2027, '2', '{\"min\":\"50\",\"max\":\"2000\",\"rate\":\"2\",\"refill\":null,\"currency\":\"USD\"}', 34, 1, '2', '1', 'Facebook - Live Stream Views [30 Min]', '', '2.4000', 50, 2000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Facebook - Live Stream Views [30 Min]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(128, 1, 2028, '2', '{\"min\":\"50\",\"max\":\"2000\",\"rate\":\"3\",\"refill\":null,\"currency\":\"USD\"}', 34, 1, '2', '1', 'Facebook - Live Stream Views [60 Min]', '', '3.6000', 50, 2000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Facebook - Live Stream Views [60 Min]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(129, 1, 2029, '2', '{\"min\":\"50\",\"max\":\"2000\",\"rate\":\"4.5\",\"refill\":null,\"currency\":\"USD\"}', 34, 1, '2', '1', 'Facebook - Live Stream Views [90 Min]', '', '5.4000', 50, 2000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Facebook - Live Stream Views [90 Min]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(130, 1, 2030, '2', '{\"min\":\"50\",\"max\":\"2000\",\"rate\":\"6\",\"refill\":null,\"currency\":\"USD\"}', 34, 1, '2', '1', 'Facebook - Live Stream Views [120 Min]', '', '7.2000', 50, 2000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Facebook - Live Stream Views [120 Min]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(131, 1, 2031, '2', '{\"min\":\"50\",\"max\":\"2000\",\"rate\":\"7\",\"refill\":null,\"currency\":\"USD\"}', 34, 1, '2', '1', 'Facebook - Live Stream Views [150 Min]', '', '8.4000', 50, 2000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Facebook - Live Stream Views [150 Min]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(132, 1, 2032, '2', '{\"min\":\"50\",\"max\":\"2000\",\"rate\":\"8.85\",\"refill\":null,\"currency\":\"USD\"}', 34, 1, '2', '1', 'Facebook - Live Stream Views [180 Min]', '', '10.6200', 50, 2000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Facebook - Live Stream Views [180 Min]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(133, 1, 2033, '2', '{\"min\":\"50\",\"max\":\"2000\",\"rate\":\"10\",\"refill\":null,\"currency\":\"USD\"}', 34, 1, '2', '1', 'Facebook - Live Stream Views [210 Min]', '', '12.0000', 50, 2000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Facebook - Live Stream Views [210 Min]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(134, 1, 2034, '2', '{\"min\":\"50\",\"max\":\"2000\",\"rate\":\"11\",\"refill\":null,\"currency\":\"USD\"}', 34, 1, '2', '1', 'Facebook - Live Stream Views [240 Min]', '', '13.2000', 50, 2000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Facebook - Live Stream Views [240 Min]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(135, 1, 2035, '2', '{\"min\":\"50\",\"max\":\"2000\",\"rate\":\"14\",\"refill\":null,\"currency\":\"USD\"}', 34, 1, '2', '1', 'Facebook - Live Stream Views [300 Min]', '', '16.8000', 50, 2000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Facebook - Live Stream Views [300 Min]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(136, 1, 2038, '2', '{\"min\":\"20\",\"max\":\"250000\",\"rate\":\"63.6\",\"refill\":null,\"currency\":\"USD\"}', 34, 1, '2', '1', 'Facebook - Live Stream Views [480 Min]', '', '76.3200', 20, 250000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Facebook - Live Stream Views [480 Min]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(137, 1, 2039, '2', '{\"min\":\"10\",\"max\":\"50000\",\"rate\":\"1.32\",\"refill\":null,\"currency\":\"USD\"}', 35, 1, '2', '1', 'Facebook Live Stream Video Likes [👍]', '', '1.5840', 10, 50000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Facebook Live Stream Video Likes [\\ud83d\\udc4d]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(138, 1, 2040, '2', '{\"min\":\"50\",\"max\":\"50000\",\"rate\":\"1.32\",\"refill\":null,\"currency\":\"USD\"}', 35, 1, '2', '1', 'Facebook Live Stream Video Reactions [❤️]', '', '1.5840', 50, 50000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Facebook Live Stream Video Reactions [\\u2764\\ufe0f]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(139, 1, 2041, '2', '{\"min\":\"50\",\"max\":\"50000\",\"rate\":\"1.32\",\"refill\":null,\"currency\":\"USD\"}', 35, 1, '2', '1', 'Facebook Live Stream Video Reactions [😮]', '', '1.5840', 50, 50000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Facebook Live Stream Video Reactions [\\ud83d\\ude2e]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(140, 1, 2042, '2', '{\"min\":\"50\",\"max\":\"50000\",\"rate\":\"1.32\",\"refill\":null,\"currency\":\"USD\"}', 35, 1, '2', '1', 'Facebook Live Stream Video Reactions [😢]', '', '1.5840', 50, 50000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Facebook Live Stream Video Reactions [\\ud83d\\ude22]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(141, 1, 2043, '2', '{\"min\":\"50\",\"max\":\"50000\",\"rate\":\"1.32\",\"refill\":null,\"currency\":\"USD\"}', 35, 1, '2', '1', 'Facebook Live Stream Video Reactions [😡]', '', '1.5840', 50, 50000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Facebook Live Stream Video Reactions [\\ud83d\\ude21]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(142, 1, 2050, '2', '{\"min\":\"500\",\"max\":\"5000\",\"rate\":\"2.34\",\"refill\":null,\"currency\":\"USD\"}', 36, 1, '2', '1', 'Discord - GLOBAL Friend Request | 𝐡𝐂𝐚𝐩𝐭𝐜𝐡𝐚 | 𝐆𝐥𝐨𝐛𝐚𝐥 | Max 50K | 0-1 Hours', '', '2.8080', 500, 5000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Discord - GLOBAL Friend Request | \\ud835\\udc21\\ud835\\udc02\\ud835\\udc1a\\ud835\\udc29\\ud835\\udc2d\\ud835\\udc1c\\ud835\\udc21\\ud835\\udc1a | \\ud835\\udc06\\ud835\\udc25\\ud835\\udc28\\ud835\\udc1b\\ud835\\udc1a\\ud835\\udc25 | Max 50K | ', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(143, 1, 2051, '2', '{\"min\":\"500\",\"max\":\"5000\",\"rate\":\"5.5\",\"refill\":null,\"currency\":\"USD\"}', 36, 1, '2', '1', 'Discord - GLOBAL SPAM Friend Request | SPAM BOMB | 𝐡𝐂𝐚𝐩𝐭𝐜𝐡𝐚 | 𝐆𝐥𝐨𝐛𝐚𝐥 | Max 2K | 0-1 Hours', '', '6.6000', 500, 5000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Discord - GLOBAL SPAM Friend Request | SPAM BOMB | \\ud835\\udc21\\ud835\\udc02\\ud835\\udc1a\\ud835\\udc29\\ud835\\udc2d\\ud835\\udc1c\\ud835\\udc21\\ud835\\udc1a | \\ud835\\udc06\\ud835\\udc25\\ud835\\udc28\\ud835\\udc1b\\ud835\\udc1a\\ud835\\u', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(144, 1, 2060, '2', '{\"min\":\"1000\",\"max\":\"15000\",\"rate\":\"18\",\"refill\":null,\"currency\":\"USD\"}', 37, 1, '2', '1', 'Discord (DM) Direct Message | Min: 20K | No Refill | Max 10M | Start: 0-24 Hours', '', '21.6000', 1000, 15000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Discord (DM) Direct Message | Min: 20K | No Refill | Max 10M | Start: 0-24 Hours\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(145, 1, 2088, '2', '{\"min\":\"10\",\"max\":\"100000\",\"rate\":\"0.324\",\"refill\":null,\"currency\":\"USD\"}', 38, 1, '2', '1', 'Telegram - Reactions 🎉 [NO DROP]', '', '0.3888', 10, 100000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Telegram - Reactions \\ud83c\\udf89 [NO DROP]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(146, 1, 2089, '2', '{\"min\":\"15\",\"max\":\"150000\",\"rate\":\"0.324\",\"refill\":null,\"currency\":\"USD\"}', 38, 1, '2', '1', 'Telegram - Reactions 🔥[NO DROP]', '', '0.3888', 15, 150000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Telegram - Reactions \\ud83d\\udd25[NO DROP]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(147, 1, 2090, '2', '{\"min\":\"15\",\"max\":\"150000\",\"rate\":\"0.324\",\"refill\":null,\"currency\":\"USD\"}', 38, 1, '2', '1', 'Telegram - Reactions ❤ [NO DROP]', '', '0.3888', 15, 150000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Telegram - Reactions \\u2764 [NO DROP]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(148, 1, 2091, '2', '{\"min\":\"15\",\"max\":\"150000\",\"rate\":\"0.324\",\"refill\":null,\"currency\":\"USD\"}', 38, 1, '2', '1', 'Telegram - Reactions 👎[NO DROP]', '', '0.3888', 15, 150000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Telegram - Reactions \\ud83d\\udc4e[NO DROP]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(149, 1, 2092, '2', '{\"min\":\"15\",\"max\":\"150000\",\"rate\":\"0.324\",\"refill\":null,\"currency\":\"USD\"}', 38, 1, '2', '1', 'Telegram - Reactions 👍[NO DROP]', '', '0.3888', 15, 150000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Telegram - Reactions \\ud83d\\udc4d[NO DROP]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(150, 1, 2094, '2', '{\"min\":\"10\",\"max\":\"10000\",\"rate\":\"21.66\",\"refill\":null,\"currency\":\"USD\"}', 38, 1, '2', '1', 'Telegram - Reactions [Auto Reaction Dislikes👎] [FreeViews 50 Future Posts]', '', '25.9920', 10, 10000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Telegram - Reactions [Auto Reaction Dislikes\\ud83d\\udc4e] [FreeViews 50 Future Posts]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(151, 1, 2096, '2', '{\"min\":\"10\",\"max\":\"1000000\",\"rate\":\"21.66\",\"refill\":null,\"currency\":\"USD\"}', 38, 1, '2', '1', 'Telegram - Reactions [Auto Reaction Mix Negative [👎 😱 💩 😢 🤮] [FreeViews 50 Future Posts]', '', '25.9920', 10, 1000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Telegram - Reactions [Auto Reaction Mix Negative [\\ud83d\\udc4e \\ud83d\\ude31 \\ud83d\\udca9 \\ud83d\\ude22 \\ud83e\\udd2e] [FreeViews 50 Future Posts]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(152, 1, 2097, '2', '{\"min\":\"100\",\"max\":\"100000\",\"rate\":\"0.0132\",\"refill\":null,\"currency\":\"USD\"}', 39, 1, '2', '1', 'Telegram - Views [1 POST]', '', '0.0158', 100, 100000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Telegram - Views [1 POST]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(153, 1, 2098, '2', '{\"min\":\"2000\",\"max\":\"5000000\",\"rate\":\"0.012\",\"refill\":null,\"currency\":\"USD\"}', 39, 1, '2', '1', 'Telegram - Views [1 POST]', '', '0.0144', 2000, 5000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Telegram - Views [1 POST]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(154, 1, 2099, '2', '{\"min\":\"2000\",\"max\":\"100000\",\"rate\":\"0.084\",\"refill\":null,\"currency\":\"USD\"}', 39, 1, '2', '1', 'Telegram - Views [1 POST]', '', '0.1008', 2000, 100000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Telegram - Views [1 POST]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(155, 1, 2100, '2', '{\"min\":\"10\",\"max\":\"500000\",\"rate\":\"0.108\",\"refill\":null,\"currency\":\"USD\"}', 39, 1, '2', '1', 'Telegram - Views [LAST 5 POST]', '', '0.1296', 10, 500000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Telegram - Views [LAST 5 POST]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(156, 1, 2101, '2', '{\"min\":\"100\",\"max\":\"250000\",\"rate\":\"0.144\",\"refill\":null,\"currency\":\"USD\"}', 39, 1, '2', '1', 'Telegram - Views [LAST 10 POST]', '', '0.1728', 100, 250000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Telegram - Views [LAST 10 POST]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(157, 1, 2102, '2', '{\"min\":\"100\",\"max\":\"250000\",\"rate\":\"0.24\",\"refill\":null,\"currency\":\"USD\"}', 39, 1, '2', '1', 'Telegram - Views [LAST 20 POST]', '', '0.2880', 100, 250000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Telegram - Views [LAST 20 POST]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(158, 1, 2103, '2', '{\"min\":\"100\",\"max\":\"250000\",\"rate\":\"0.36\",\"refill\":null,\"currency\":\"USD\"}', 39, 1, '2', '1', 'Telegram - Views [ LAST 50 POST]', '', '0.4320', 100, 250000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Telegram - Views [ LAST 50 POST]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(159, 1, 2104, '2', '{\"min\":\"100\",\"max\":\"25000\",\"rate\":\"0.48\",\"refill\":null,\"currency\":\"USD\"}', 39, 1, '2', '1', 'Telegram - Views [LAST 100 POST]', '', '0.5760', 100, 25000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Telegram - Views [LAST 100 POST]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(160, 1, 2120, '2', '{\"min\":\"50\",\"max\":\"45500\",\"rate\":\"0.6\",\"refill\":null,\"currency\":\"USD\"}', 40, 1, '2', '1', 'Telegram - Members [Channel/Group Members] [IOS USERS]', '', '0.7200', 50, 45500, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Telegram - Members [Channel\\/Group Members] [IOS USERS]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(161, 1, 2123, '2', '{\"min\":\"100\",\"max\":\"50000\",\"rate\":\"2\",\"refill\":null,\"currency\":\"USD\"}', 40, 1, '2', '1', 'Telegram - Members [Channel/Group Members] [MIX] [FAST]', '', '2.4000', 100, 50000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Telegram - Members [Channel\\/Group Members] [MIX] [FAST]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(162, 1, 2135, '2', '{\"min\":\"100\",\"max\":\"1000000\",\"rate\":\"1.51\",\"refill\":null,\"currency\":\"USD\"}', 41, 1, '2', '1', 'Telegram [Channel/Group Members] [REAL] [Non Drop] [FAST]', '', '1.8120', 100, 1000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Telegram [Channel\\/Group Members] [REAL] [Non Drop] [FAST]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(163, 1, 2136, '2', '{\"min\":\"10\",\"max\":\"50000\",\"rate\":\"0.93\",\"refill\":null,\"currency\":\"USD\"}', 42, 1, '2', '1', 'Telegram [Channel/Group Members] [IRAN🇮🇷]', '', '1.1160', 10, 50000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Telegram [Channel\\/Group Members] [IRAN\\ud83c\\uddee\\ud83c\\uddf7]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(164, 1, 2138, '2', '{\"min\":\"10\",\"max\":\"300000\",\"rate\":\"1.5\",\"refill\":null,\"currency\":\"USD\"}', 42, 1, '2', '1', 'Telegram [Channel/Group Members] [USA🇺🇸IRAN🇮🇷]', '', '1.8000', 10, 300000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Telegram [Channel\\/Group Members] [USA\\ud83c\\uddfa\\ud83c\\uddf8IRAN\\ud83c\\uddee\\ud83c\\uddf7]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(165, 1, 2141, '2', '{\"min\":\"100\",\"max\":\"100000\",\"rate\":\"1.5\",\"refill\":null,\"currency\":\"USD\"}', 43, 1, '2', '1', 'Telegram [Channel/Group Members] [REAL USA🇺🇸]', '', '1.8000', 100, 100000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Telegram [Channel\\/Group Members] [REAL USA\\ud83c\\uddfa\\ud83c\\uddf8]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(166, 1, 2142, '2', '{\"min\":\"20\",\"max\":\"50000\",\"rate\":\"0.996\",\"refill\":null,\"currency\":\"USD\"}', 43, 1, '2', '1', 'Telegram [Channel/Group Members] [REAL RUSSIAN🇷🇺]', '', '1.1952', 20, 50000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Telegram [Channel\\/Group Members] [REAL RUSSIAN\\ud83c\\uddf7\\ud83c\\uddfa]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(167, 1, 2144, '2', '{\"min\":\"10\",\"max\":\"100000\",\"rate\":\"1.3\",\"refill\":null,\"currency\":\"USD\"}', 43, 1, '2', '1', 'Telegram [Channel/Group Members] [REAL INDONESIAN🇮🇩]', '', '1.5600', 10, 100000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Telegram [Channel\\/Group Members] [REAL INDONESIAN\\ud83c\\uddee\\ud83c\\udde9]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(168, 1, 2145, '2', '{\"min\":\"10\",\"max\":\"50000\",\"rate\":\"1.728\",\"refill\":null,\"currency\":\"USD\"}', 43, 1, '2', '1', 'Telegram [Channel/Group Members] [REAL ARABIC🇦🇪]', '', '2.0736', 10, 50000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Telegram [Channel\\/Group Members] [REAL ARABIC\\ud83c\\udde6\\ud83c\\uddea]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(169, 1, 2146, '2', '{\"min\":\"10\",\"max\":\"20000\",\"rate\":\"1.728\",\"refill\":null,\"currency\":\"USD\"}', 43, 1, '2', '1', 'Telegram [Channel/Group Members] [REAL CHINA🇨🇳]', '', '2.0736', 10, 20000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Telegram [Channel\\/Group Members] [REAL CHINA\\ud83c\\udde8\\ud83c\\uddf3]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(170, 1, 2148, '2', '{\"min\":\"1000\",\"max\":\"100000\",\"rate\":\"1.26\",\"refill\":null,\"currency\":\"USD\"}', 44, 1, '2', '1', 'Telegram [Channel/Group Members] [RUSSIAN🇷🇺] [BOT]', '', '1.5120', 1000, 100000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Telegram [Channel\\/Group Members] [RUSSIAN\\ud83c\\uddf7\\ud83c\\uddfa] [BOT]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(171, 1, 2151, '2', '{\"min\":\"10\",\"max\":\"10000000\",\"rate\":\"1.5\",\"refill\":null,\"currency\":\"USD\"}', 44, 1, '2', '1', 'Telegram [Channel/Group Members] [IRAN🇮🇷] [BOT]', '', '1.8000', 10, 10000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Telegram [Channel\\/Group Members] [IRAN\\ud83c\\uddee\\ud83c\\uddf7] [BOT]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(172, 1, 2153, '2', '{\"min\":\"10\",\"max\":\"500000\",\"rate\":\"0.432\",\"refill\":null,\"currency\":\"USD\"}', 45, 1, '2', '1', 'Telegram Vote [INSTANT] [SUPER FAST]', '', '0.5184', 10, 500000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Telegram Vote [INSTANT] [SUPER FAST]\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(173, 1, 2330, '2', '{\"min\":\"1000\",\"max\":\"10000000\",\"rate\":\"5.304\",\"refill\":null,\"currency\":\"USD\"}', 46, 1, '2', '1', 'ClubHouse 1000 Provider Followers', '', '6.3648', 1000, 10000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"ClubHouse 1000 Provider Followers\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(174, 1, 2509, '2', '{\"min\":\"10\",\"max\":\"50000\",\"rate\":\"0.01\",\"refill\":null,\"currency\":\"USD\"}', 47, 1, '2', '1', 'Instagram Save Max 15K | 0-30 Minutes', '', '0.0120', 10, 50000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Save Max 15K | 0-30 Minutes\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(175, 1, 2510, '2', '{\"min\":\"10\",\"max\":\"100000\",\"rate\":\"0.03\",\"refill\":null,\"currency\":\"USD\"}', 47, 1, '2', '1', 'Instagram Save Max 100K | 0-30 Minutes', '', '0.0360', 10, 100000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Save Max 100K | 0-30 Minutes\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(176, 1, 2511, '2', '{\"min\":\"100\",\"max\":\"100000\",\"rate\":\"0.2\",\"refill\":null,\"currency\":\"USD\"}', 47, 1, '2', '1', 'Instagram Story Views | All Story Max 1M | 0-15 Minutes', '', '0.2400', 100, 100000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Story Views | All Story Max 1M | 0-15 Minutes\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(177, 1, 2512, '2', '{\"min\":\"10\",\"max\":\"1000000\",\"rate\":\"0.0072\",\"refill\":null,\"currency\":\"USD\"}', 47, 1, '2', '1', 'Instagram Story Views | All Story Max 1M | 0-15 Minutes', '', '0.0086', 10, 1000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Story Views | All Story Max 1M | 0-15 Minutes\"}', '{\"en\":\"\"}', 'Not enough data', 'Not enough data', '2', 'false', '20', '30', '24', 0, 0, 0, 0),
(178, 1, 2546, '2', '{\"min\":\"100\",\"max\":\"50000\",\"rate\":\"0.018\",\"currency\":\"USD\"}', 47, 2, '2', '11', 'Auto', NULL, '1000', 100, 10000, '1', 0, 0, '4', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Auto\"}', NULL, 'Not enough data', 'Not enough data', '2', 'false', '', '30', '24', 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `service_api`
--

CREATE TABLE `service_api` (
  `id` int(11) NOT NULL,
  `api_name` varchar(225) NOT NULL,
  `api_url` text NOT NULL,
  `api_key` varchar(225) NOT NULL,
  `api_type` int(11) NOT NULL,
  `api_limit` double NOT NULL DEFAULT '0',
  `currency` enum('INR','USD') DEFAULT NULL,
  `api_alert` enum('1','2') NOT NULL DEFAULT '2' COMMENT '2 -> Gönder, 1 -> Gönderildi',
  `status` enum('1','2') NOT NULL DEFAULT '2'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `site_seo` text NOT NULL,
  `site_title` text,
  `site_description` text,
  `site_keywords` text,
  `site_logo` text,
  `site_name` text,
  `site_currency` varchar(2555) NOT NULL DEFAULT 'try',
  `favicon` text,
  `site_language` varchar(225) NOT NULL DEFAULT 'tr',
  `site_theme` text NOT NULL,
  `site_theme_alt` text,
  `recaptcha` enum('1','2') NOT NULL DEFAULT '1',
  `recaptcha_key` text,
  `recaptcha_secret` text,
  `custom_header` text,
  `custom_footer` text,
  `ticket_system` enum('1','2') NOT NULL DEFAULT '2',
  `register_page` enum('1','2') NOT NULL DEFAULT '2',
  `service_speed` enum('1','2') NOT NULL,
  `service_list` enum('1','2') NOT NULL,
  `dolar_charge` double NOT NULL,
  `euro_charge` double NOT NULL,
  `smtp_user` text NOT NULL,
  `smtp_pass` text NOT NULL,
  `smtp_server` text NOT NULL,
  `smtp_port` varchar(225) NOT NULL,
  `smtp_protocol` enum('0','ssl','tls') NOT NULL,
  `alert_type` enum('1','2','3') NOT NULL,
  `alert_apimail` enum('1','2') NOT NULL,
  `alert_newmanuelservice` enum('1','2') NOT NULL,
  `alert_newticket` enum('1','2') NOT NULL,
  `alert_apibalance` enum('1','2') NOT NULL,
  `alert_serviceapialert` enum('1','2') NOT NULL,
  `sms_provider` varchar(225) NOT NULL,
  `sms_title` varchar(225) NOT NULL,
  `sms_user` varchar(225) NOT NULL,
  `sms_pass` varchar(225) NOT NULL,
  `sms_validate` enum('0','1') NOT NULL DEFAULT '0' COMMENT '1 -> OK, 0 -> NO',
  `admin_mail` varchar(225) NOT NULL,
  `admin_telephone` varchar(225) NOT NULL,
  `resetpass_page` enum('1','2') NOT NULL,
  `resetpass_sms` enum('1','2') NOT NULL,
  `resetpass_email` enum('1','2') NOT NULL,
  `site_maintenance` enum('1','2') NOT NULL DEFAULT '2',
  `servis_siralama` varchar(255) NOT NULL,
  `bronz_statu` int(11) NOT NULL,
  `silver_statu` int(11) NOT NULL,
  `gold_statu` int(11) NOT NULL,
  `bayi_statu` int(11) NOT NULL,
  `ns1` varchar(191) DEFAULT NULL,
  `ns2` varchar(191) DEFAULT NULL,
  `childpanel_price` double DEFAULT NULL,
  `snow_effect` enum('1','2') NOT NULL DEFAULT '2',
  `snow_colour` text NOT NULL,
  `promotion` enum('1','2') DEFAULT '2',
  `referral_commision` double NOT NULL,
  `referral_payout` double NOT NULL,
  `referral_status` enum('1','2') NOT NULL DEFAULT '1',
  `childpanel_selling` enum('1','2') NOT NULL DEFAULT '1',
  `tickets_per_user` double NOT NULL DEFAULT '5',
  `name_fileds` enum('1','2') NOT NULL DEFAULT '1' COMMENT '1 -> ON, 2 -> NO',
  `skype_feilds` enum('1','2') NOT NULL DEFAULT '1' COMMENT '1 -> ON, 2 -> NO',
  `csymbol` text NOT NULL,
  `inr_symbol` text NOT NULL,
  `inr_value` double NOT NULL DEFAULT '0',
  `usd_symbol` text NOT NULL,
  `inr_convert` double NOT NULL DEFAULT '0',
  `otp_login` enum('1','2','0') NOT NULL DEFAULT '0',
  `auto_deactivate_payment` enum('1','2') NOT NULL DEFAULT '1',
  `service_avg_time` enum('1','0') NOT NULL DEFAULT '0',
  `alert_orderfail` enum('1','2') NOT NULL DEFAULT '2',
  `alert_welcomemail` enum('1','2') NOT NULL DEFAULT '2',
  `freebalance` enum('1','2') NOT NULL DEFAULT '1',
  `freeamount` double DEFAULT '0',
  `alert_newmessage` enum('1','2') NOT NULL DEFAULT '1',
  `email_confirmation` enum('1','2') NOT NULL DEFAULT '2',
  `resend_max` int(11) NOT NULL,
  `orders` int(255) NOT NULL,
  `orders_id` int(11) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT '1',
  `neworder_blocks` enum('1','2') NOT NULL DEFAULT '2',
  `decoration_ligts` enum('1','2') NOT NULL DEFAULT '2'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `site_seo`, `site_title`, `site_description`, `site_keywords`, `site_logo`, `site_name`, `site_currency`, `favicon`, `site_language`, `site_theme`, `site_theme_alt`, `recaptcha`, `recaptcha_key`, `recaptcha_secret`, `custom_header`, `custom_footer`, `ticket_system`, `register_page`, `service_speed`, `service_list`, `dolar_charge`, `euro_charge`, `smtp_user`, `smtp_pass`, `smtp_server`, `smtp_port`, `smtp_protocol`, `alert_type`, `alert_apimail`, `alert_newmanuelservice`, `alert_newticket`, `alert_apibalance`, `alert_serviceapialert`, `sms_provider`, `sms_title`, `sms_user`, `sms_pass`, `sms_validate`, `admin_mail`, `admin_telephone`, `resetpass_page`, `resetpass_sms`, `resetpass_email`, `site_maintenance`, `servis_siralama`, `bronz_statu`, `silver_statu`, `gold_statu`, `bayi_statu`, `ns1`, `ns2`, `childpanel_price`, `snow_effect`, `snow_colour`, `promotion`, `referral_commision`, `referral_payout`, `referral_status`, `childpanel_selling`, `tickets_per_user`, `name_fileds`, `skype_feilds`, `csymbol`, `inr_symbol`, `inr_value`, `usd_symbol`, `inr_convert`, `otp_login`, `auto_deactivate_payment`, `service_avg_time`, `alert_orderfail`, `alert_welcomemail`, `freebalance`, `freeamount`, `alert_newmessage`, `email_confirmation`, `resend_max`, `orders`, `orders_id`, `status`, `neworder_blocks`, `decoration_ligts`) VALUES
(1, 'smmscript.shop', 'smmscript.shop', 'smmscript.shop', 'smmscript.shop', '', 'SMMSCRIPT.SHOP', 'USD', '', 'en', 'Clementine', 'orange', '1', '6LfQ414eAAAAAD0B3Nx7vmhg3rw8Ae7T-4dfI1ii', '6LfQ414eAAAAAL3jYAvNPi5xJJ6M89CcdFFxritH', '', '', '1', '2', '1', '2', 0, 0, '', '121345', '', '465', 'ssl', '2', '2', '2', '2', '2', '2', 'bizimsms', '', '', '', '1', '', '', '2', '1', '2', '2', 'asc', 500, 2500, 10000, 15000, 'rental1.mysecurepanel.com', 'rental2.mysecurepanel.com', 10, '1', '#ffffff', '1', 5, 10, '2', '2', 9999999999, '2', '2', '$', '₹', 74.87, '$', 0.013, '0', '1', '1', '2', '2', '1', 0, '2', '2', 1, 191530, 80, '0', '2', '2');

-- --------------------------------------------------------

--
-- Table structure for table `sync_logs`
--

CREATE TABLE `sync_logs` (
  `id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `action` varchar(225) NOT NULL,
  `date` datetime NOT NULL,
  `description` varchar(225) NOT NULL,
  `api_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `themes`
--

CREATE TABLE `themes` (
  `id` int(11) NOT NULL,
  `theme_name` text NOT NULL,
  `theme_dirname` text NOT NULL,
  `theme_extras` text NOT NULL,
  `last_modified` datetime NOT NULL,
  `newpage` text NOT NULL,
  `colour` enum('1','2') NOT NULL DEFAULT '1',
  `site_theme_alt` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `themes`
--

INSERT INTO `themes` (`id`, `theme_name`, `theme_dirname`, `theme_extras`, `last_modified`, `newpage`, `colour`, `site_theme_alt`) VALUES
(1, 'Clementine', 'Clementine', '', '2022-03-04 01:14:03', '{% include \'header.twig\' %}\r\n	<br><br><br>\r\n	\r\n	<div class=\"container-fluid container-fluid-spacious\">\r\n		<div class=\"row\">\r\n			<div class=\"col-md-12\">\r\n			{% if contentText %}\r\n{{ contentText }}\r\n{% endif %}\r\n				{% if contentText2 %}\r\n{{ contentText2 }}\r\n{% endif %}\r\n				\r\n			</div>\r\n		</div>\r\n	</div>\r\n   \r\n      \r\n        \r\n   ', '2', '');

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `ticket_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `subject` varchar(225) NOT NULL,
  `time` datetime NOT NULL,
  `lastupdate_time` datetime NOT NULL,
  `client_new` enum('1','2') NOT NULL DEFAULT '2',
  `status` enum('pending','answered','closed') NOT NULL DEFAULT 'pending',
  `support_new` enum('1','2') NOT NULL DEFAULT '1',
  `canmessage` enum('1','2') NOT NULL DEFAULT '2'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_reply`
--

CREATE TABLE `ticket_reply` (
  `id` int(11) NOT NULL,
  `ticket_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `time` datetime NOT NULL,
  `support` enum('1','2') NOT NULL DEFAULT '1',
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `readed` enum('1','2') NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_subjects`
--

CREATE TABLE `ticket_subjects` (
  `subject_id` int(11) NOT NULL,
  `subject` varchar(225) NOT NULL,
  `content` text,
  `auto_reply` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `ticket_subjects`
--

INSERT INTO `ticket_subjects` (`subject_id`, `subject`, `content`, `auto_reply`) VALUES
(2, 'Payment', '', '0'),
(4, 'Complaint & Suggestion', '', '0'),
(6, 'Others', '', '0');

-- --------------------------------------------------------

--
-- Table structure for table `units_per_page`
--

CREATE TABLE `units_per_page` (
  `id` int(11) NOT NULL,
  `unit` int(11) NOT NULL,
  `page` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `units_per_page`
--

INSERT INTO `units_per_page` (`id`, `unit`, `page`) VALUES
(1, 50, 'clients'),
(2, 50, 'orders'),
(3, 50, 'payments'),
(4, 50, 'refill'),
(5, 50, 'bulk');

-- --------------------------------------------------------

--
-- Table structure for table `updates`
--

CREATE TABLE `updates` (
  `u_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `action` varchar(225) NOT NULL,
  `date` datetime NOT NULL,
  `description` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT 'Not enough data'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `updates`
--

INSERT INTO `updates` (`u_id`, `service_id`, `action`, `date`, `description`) VALUES
(1, 1, 'Activated', '2022-12-18 14:15:33', 'Refill Button has been activated'),
(2, 1, 'Disabled', '2022-12-18 14:15:36', 'Refill Button has been disabled'),
(3, 1, 'Activated', '2022-12-20 23:19:11', 'Refill Button has been activated');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`id`),
  ADD KEY `title` (`title`);

--
-- Indexes for table `bank_accounts`
--
ALTER TABLE `bank_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blogs`
--
ALTER TABLE `blogs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bulkedit`
--
ALTER TABLE `bulkedit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `childpanels`
--
ALTER TABLE `childpanels`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`client_id`);

--
-- Indexes for table `clients_category`
--
ALTER TABLE `clients_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clients_price`
--
ALTER TABLE `clients_price`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clients_service`
--
ALTER TABLE `clients_service`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `client_report`
--
ALTER TABLE `client_report`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `currency`
--
ALTER TABLE `currency`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `earn`
--
ALTER TABLE `earn`
  ADD PRIMARY KEY (`earn_id`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `General_options`
--
ALTER TABLE `General_options`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `integrations`
--
ALTER TABLE `integrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kuponlar`
--
ALTER TABLE `kuponlar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kupon_kullananlar`
--
ALTER TABLE `kupon_kullananlar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Mailforms`
--
ALTER TABLE `Mailforms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications_popup`
--
ALTER TABLE `notifications_popup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`) USING BTREE;

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`page_id`);

--
-- Indexes for table `panel_categories`
--
ALTER TABLE `panel_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `panel_info`
--
ALTER TABLE `panel_info`
  ADD PRIMARY KEY (`panel_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `payments_bonus`
--
ALTER TABLE `payments_bonus`
  ADD PRIMARY KEY (`bonus_id`);

--
-- Indexes for table `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_methodsold`
--
ALTER TABLE `payment_methodsold`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `referral`
--
ALTER TABLE `referral`
  ADD PRIMARY KEY (`referral_id`);

--
-- Indexes for table `referral_payouts`
--
ALTER TABLE `referral_payouts`
  ADD PRIMARY KEY (`r_p_id`);

--
-- Indexes for table `refill_status`
--
ALTER TABLE `refill_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `serviceapi_alert`
--
ALTER TABLE `serviceapi_alert`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`service_id`);

--
-- Indexes for table `service_api`
--
ALTER TABLE `service_api`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sync_logs`
--
ALTER TABLE `sync_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `themes`
--
ALTER TABLE `themes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`ticket_id`);

--
-- Indexes for table `ticket_reply`
--
ALTER TABLE `ticket_reply`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ticket_subjects`
--
ALTER TABLE `ticket_subjects`
  ADD PRIMARY KEY (`subject_id`);

--
-- Indexes for table `units_per_page`
--
ALTER TABLE `units_per_page`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `updates`
--
ALTER TABLE `updates`
  ADD PRIMARY KEY (`u_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `article`
--
ALTER TABLE `article`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bank_accounts`
--
ALTER TABLE `bank_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `blogs`
--
ALTER TABLE `blogs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bulkedit`
--
ALTER TABLE `bulkedit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `childpanels`
--
ALTER TABLE `childpanels`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `client_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `clients_category`
--
ALTER TABLE `clients_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `clients_price`
--
ALTER TABLE `clients_price`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `clients_service`
--
ALTER TABLE `clients_service`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `client_report`
--
ALTER TABLE `client_report`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `currency`
--
ALTER TABLE `currency`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `earn`
--
ALTER TABLE `earn`
  MODIFY `earn_id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `General_options`
--
ALTER TABLE `General_options`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `integrations`
--
ALTER TABLE `integrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `kuponlar`
--
ALTER TABLE `kuponlar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `kupon_kullananlar`
--
ALTER TABLE `kupon_kullananlar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `languages`
--
ALTER TABLE `languages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `Mailforms`
--
ALTER TABLE `Mailforms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `notifications_popup`
--
ALTER TABLE `notifications_popup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `page_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=904;

--
-- AUTO_INCREMENT for table `panel_categories`
--
ALTER TABLE `panel_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `panel_info`
--
ALTER TABLE `panel_info`
  MODIFY `panel_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `payments_bonus`
--
ALTER TABLE `payments_bonus`
  MODIFY `bonus_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment_methods`
--
ALTER TABLE `payment_methods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `payment_methodsold`
--
ALTER TABLE `payment_methodsold`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `referral`
--
ALTER TABLE `referral`
  MODIFY `referral_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `referral_payouts`
--
ALTER TABLE `referral_payouts`
  MODIFY `r_p_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `refill_status`
--
ALTER TABLE `refill_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `serviceapi_alert`
--
ALTER TABLE `serviceapi_alert`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `service_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=179;

--
-- AUTO_INCREMENT for table `service_api`
--
ALTER TABLE `service_api`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sync_logs`
--
ALTER TABLE `sync_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `themes`
--
ALTER TABLE `themes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=268;

--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `ticket_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ticket_reply`
--
ALTER TABLE `ticket_reply`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ticket_subjects`
--
ALTER TABLE `ticket_subjects`
  MODIFY `subject_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `units_per_page`
--
ALTER TABLE `units_per_page`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `updates`
--
ALTER TABLE `updates`
  MODIFY `u_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
