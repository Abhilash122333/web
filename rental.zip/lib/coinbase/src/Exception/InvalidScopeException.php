<?php

namespace Coinbase\Wallet\Exception;

class InvalidScopeException extends HttpException
{
}
