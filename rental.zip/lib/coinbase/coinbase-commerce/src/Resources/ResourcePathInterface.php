<?php
namespace CoinbaseCommerce\Resources;

interface ResourcePathInterface
{
    public static function getResourcePath();
}