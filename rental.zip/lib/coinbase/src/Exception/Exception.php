<?php

namespace Coinbase\Wallet\Exception;

interface Exception 
{
}
