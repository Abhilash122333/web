<?php
namespace CoinbaseCommerce\Exceptions;

class ValidationException extends ApiException
{
}
