<?php
namespace CoinbaseCommerce\Exceptions;

class ServiceUnavailableException extends ApiException
{
}
