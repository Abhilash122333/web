<?php include 'header.php'; ?>


<div class="col-md-12">
   <div class="panel panel-default">
      <div class="panel-body">
        <div class="col-md-9" style="margin:50px auto">
          <center><b style="font-size:25px;">You Don't Have Permission to access this page.</b></center>
        </div>
        <div class="col-md-3">
        <i class="fa fa-user-secret" style="font-size:125px;color:red;"></i>
        </div>
      </div>
   </div>
</div>

<?php include 'footer.php'; ?>