<?php

namespace Coinbase\Wallet\Exception;

class PersonalDetailsRequiredException extends BadRequestException
{
}
