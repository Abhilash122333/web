<?php
namespace CoinbaseCommerce\Exceptions;

class ParamRequiredException extends ApiException
{
}
