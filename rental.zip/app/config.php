<?php
				

				
define('PATH', realpath('.'));
define('SUBFOLDER', false);
define('URL', 'https://freesmm.smmmdemo.tk' );
define('STYLESHEETS_URL', '//freesmm.smmmdemo.tk' );
error_reporting(1);
date_default_timezone_set('Asia/Kolkata');

return [
  'db' => [
    'name'    =>  'smmscrip_free' ,
    'host'    =>  'localhost',
    'user'    =>  'smmscrip_free' ,
    'pass'    =>  ';7z73CMSRd2V' ,
    'charset' =>  'utf8mb4' 
  ]
];

?>